import React, { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { User } from "../../../types";
import { useTableGrouping } from "./table/hooks/useTableGrouping";
import { TableHeader } from "./table/components/TableHeader";
import { TableGroupRow } from "./table/components/TableGroupRow";
import { EmployeeRow } from "./table/components/EmployeeRow";
import { UserStat, GroupMode, DashboardTableProps } from "./table/types";
import { BRAND_CONFIG } from "../../../config/brand";

const DashboardTable: React.FC<DashboardTableProps> = ({
  isLoading,
  filteredStats,
  users,
  getGrade,
  onUserClick,
  activeStatFilter,
  sortDirection,
  onSortDirectionChange,
  currentMonth,
  workingDaysCount,
  lateViewMode = "DAYS",
  onLateViewModeChange,
  otViewMode = "HOURS",
  onOtViewModeChange,
  hpViewMode = "MONTHLY",
  onHpViewModeChange,
  snapshots = [],
}) => {
  const [groupMode, setGroupMode] = useState<GroupMode>("POSITION");
  // Collapsible states: initially all expanded
  const [collapsedGroups, setCollapsedGroups] = useState<
    Record<string, boolean>
  >({});
  const [isScanning, setIsScanning] = useState(false);

  useEffect(() => {
    setIsScanning(true);
    const timer = setTimeout(() => {
      setIsScanning(false);
    }, 500);
    return () => clearTimeout(timer);
  }, [activeStatFilter, groupMode]);

  const toggleGroup = (groupId: string) => {
    setCollapsedGroups((prev) => ({
      ...prev,
      [groupId]: !prev[groupId],
    }));
  };

  // Group and sort logic is cleanly encapsulated inside the custom hook
  const { groups, groupedData } = useTableGrouping({
    filteredStats,
    users,
    groupMode,
    sortDirection,
    activeStatFilter,
    lateViewMode,
  });

  const userMap = React.useMemo(() => {
    return new Map(users.map((u) => [u.id, u]));
  }, [users]);

  return (
    <div className="bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden flex flex-col">
      {/* Table Control Header Component */}
      <TableHeader
        groupMode={groupMode}
        setGroupMode={setGroupMode}
        sortDirection={sortDirection}
        onSortDirectionChange={onSortDirectionChange}
        activeStatFilter={activeStatFilter}
      />

      <div className="overflow-x-auto relative [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
        {/* Dynamic Scan Line Indicator */}
        <AnimatePresence>
          {isScanning && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 pointer-events-none z-10 overflow-hidden"
            >
              <motion.div
                className="h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent w-full shadow-[0_0_8px_rgba(99,102,241,0.5)]"
                initial={{ top: "0%" }}
                animate={{ top: "100%" }}
                transition={{ duration: 0.5, ease: "easeInOut" }}
                style={{ position: "absolute" }}
              />
              <div className="absolute inset-0 bg-indigo-500/[0.02] animate-pulse" />
            </motion.div>
          )}
        </AnimatePresence>

        <table className="w-full text-left">
          <thead>
            <tr className="bg-gray-50/80 border-b border-gray-100 text-xs text-gray-500 uppercase">
              <th className="px-6 py-4 font-bold">Employee</th>

              {/* Days Present Header */}
              <th
                className={`px-6 py-4 font-bold text-center select-none transition-colors ${
                  activeStatFilter === "PRESENT" || activeStatFilter === "ALL"
                    ? "cursor-pointer text-indigo-600 hover:bg-indigo-50/40 rounded-t-lg"
                    : ""
                }`}
                onClick={() => {
                  if (
                    activeStatFilter === "PRESENT" ||
                    activeStatFilter === "ALL"
                  ) {
                    onSortDirectionChange(
                      sortDirection === "ASC" ? "DESC" : "ASC"
                    );
                  }
                }}
              >
                <div className="flex items-center justify-center gap-1">
                  <span>Days Present</span>
                  {(activeStatFilter === "PRESENT" ||
                    activeStatFilter === "ALL") &&
                    (sortDirection === "ASC" ? (
                      <span className="text-indigo-500">▲</span>
                    ) : (
                      <span className="text-indigo-500">▼</span>
                    ))}
                </div>
              </th>

              {/* Late Count Header */}
              <th
                className={`px-6 py-4 font-bold text-center select-none transition-colors ${
                  activeStatFilter === "LATE"
                    ? "cursor-pointer text-red-600 hover:bg-red-50/40 rounded-t-lg"
                    : ""
                }`}
                onClick={() => {
                  if (activeStatFilter === "LATE") {
                    onSortDirectionChange(
                      sortDirection === "ASC" ? "DESC" : "ASC"
                    );
                  }
                }}
              >
                <div className="flex items-center justify-center gap-2">
                  <span className="whitespace-nowrap">LATE</span>
                  <motion.button
                    type="button"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={(e) => {
                      e.stopPropagation();
                      onLateViewModeChange?.(lateViewMode === "DAYS" ? "HOURS" : "DAYS");
                    }}
                    className={`inline-flex items-center h-6 px-2 py-0.5 text-[11px] font-semibold rounded-full border transition-colors duration-200 cursor-pointer ${
                      lateViewMode === "DAYS"
                        ? "bg-red-50 border-red-200 text-red-600 hover:bg-red-100"
                        : "bg-amber-50 border-amber-200 text-amber-700 hover:bg-amber-100"
                    }`}
                  >
                    <AnimatePresence mode="wait">
                      <motion.span
                        key={lateViewMode}
                        initial={{ opacity: 0, y: -4 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 4 }}
                        transition={{ duration: 0.12 }}
                        className="inline-flex items-center gap-1"
                      >
                        <span>{lateViewMode === "DAYS" ? "Days" : "Hrs"}</span>
                        <span className="text-[10px] opacity-70">⇄</span>
                      </motion.span>
                    </AnimatePresence>
                  </motion.button>
                  {activeStatFilter === "LATE" &&
                    (sortDirection === "ASC" ? (
                      <span className="text-red-500">▲</span>
                    ) : (
                      <span className="text-red-500">▼</span>
                    ))}
                </div>
              </th>

              {/* Absent Header */}
              <th
                className={`px-6 py-4 font-bold text-center select-none transition-colors ${
                  activeStatFilter === "ABSENT"
                    ? "cursor-pointer text-red-600 hover:bg-red-50/40 rounded-t-lg"
                    : ""
                }`}
                onClick={() => {
                  if (activeStatFilter === "ABSENT") {
                    onSortDirectionChange(
                      sortDirection === "ASC" ? "DESC" : "ASC"
                    );
                  }
                }}
              >
                <div className="flex items-center justify-center gap-1">
                  <span>Absent</span>
                  {activeStatFilter === "ABSENT" &&
                    (sortDirection === "ASC" ? (
                      <span className="text-red-500">▲</span>
                    ) : (
                      <span className="text-red-500">▼</span>
                    ))}
                </div>
              </th>

              {/* Leaves Header */}
              <th
                className={`px-6 py-4 font-bold text-center select-none transition-colors ${
                  activeStatFilter === "LEAVE"
                    ? "cursor-pointer text-pink-600 hover:bg-pink-50/40 rounded-t-lg"
                    : ""
                }`}
                onClick={() => {
                  if (activeStatFilter === "LEAVE") {
                    onSortDirectionChange(
                      sortDirection === "ASC" ? "DESC" : "ASC"
                    );
                  }
                }}
              >
                <div className="flex items-center justify-center gap-1">
                  <span>Leaves</span>
                  {activeStatFilter === "LEAVE" &&
                    (sortDirection === "ASC" ? (
                      <span className="text-pink-500">▲</span>
                    ) : (
                      <span className="text-pink-500">▼</span>
                    ))}
                </div>
              </th>

              {/* Overtime (OT) Header */}
              <th className="px-6 py-4 font-bold text-center select-none transition-colors">
                <div className="flex items-center justify-center gap-2">
                  <span className="whitespace-nowrap">OT</span>
                  <motion.button
                    type="button"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={(e) => {
                      e.stopPropagation();
                      const modes: ("HOURS" | "LUMP_SUM" | "BOTH" | "PAYOUT")[] = ["HOURS", "LUMP_SUM", "BOTH", "PAYOUT"];
                      const nextIndex = (modes.indexOf(otViewMode) + 1) % modes.length;
                      onOtViewModeChange?.(modes[nextIndex]);
                    }}
                    className={`inline-flex items-center justify-center h-6 w-[88px] px-1.5 py-0.5 text-[10px] font-semibold rounded-full border transition-colors duration-200 cursor-pointer whitespace-nowrap ${
                      otViewMode === "HOURS"
                        ? "bg-purple-50 border-purple-200 text-purple-600 hover:bg-purple-100"
                        : otViewMode === "LUMP_SUM"
                        ? "bg-indigo-50 border-indigo-200 text-indigo-700 hover:bg-indigo-100"
                        : otViewMode === "BOTH"
                        ? "bg-sky-50 border-sky-200 text-sky-700 hover:bg-sky-100"
                        : "bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100"
                    }`}
                  >
                    <AnimatePresence mode="wait">
                      <motion.span
                        key={otViewMode}
                        initial={{ opacity: 0, y: -4 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 4 }}
                        transition={{ duration: 0.12 }}
                        className="inline-flex items-center gap-1"
                      >
                        <span>
                          {otViewMode === "HOURS"
                            ? "⏱️ Hrs"
                            : otViewMode === "LUMP_SUM"
                            ? "💵 Lump"
                            : otViewMode === "BOTH"
                            ? "🌀 All"
                            : "💰 Payout ฿"}
                        </span>
                        <span className="text-[10px] opacity-70">⇄</span>
                      </motion.span>
                    </AnimatePresence>
                  </motion.button>
                </div>
              </th>

              <th
                className="px-4 py-4 font-bold text-center select-none cursor-pointer hover:bg-gray-100/50 active:scale-[0.98] transition-all rounded-t-lg"
                onClick={() => {
                  onHpViewModeChange?.(hpViewMode === 'MONTHLY' ? 'YEARLY' : 'MONTHLY');
                }}
              >
                <div className="flex items-center justify-center gap-1.5 h-6">
                  <span className="text-xs text-gray-500 uppercase font-bold whitespace-nowrap">
                    HP
                  </span>
                  <div
                    className={`inline-flex items-center justify-center h-5 w-[58px] text-[10px] font-semibold rounded-full border transition-colors duration-200 ${
                      hpViewMode === 'MONTHLY'
                        ? "bg-indigo-50 border-indigo-200 text-indigo-700"
                        : "bg-emerald-50 border-emerald-200 text-emerald-700"
                    }`}
                  >
                    <AnimatePresence mode="wait">
                      <motion.span
                        key={hpViewMode}
                        initial={{ opacity: 0, y: -4 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 4 }}
                        transition={{ duration: 0.12 }}
                        className="inline-flex items-center gap-0.5"
                      >
                        <span>{hpViewMode === 'MONTHLY' ? 'Month' : 'Year'}</span>
                        <span className="text-[9px] opacity-70">⇄</span>
                      </motion.span>
                    </AnimatePresence>
                  </div>
                </div>
              </th>

              <th className="px-6 py-4 font-bold text-center">Total Hours</th>
              {BRAND_CONFIG.showGradeMode !== 2 && (
                <th className="px-6 py-4 font-bold text-center">Grade</th>
              )}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {isLoading ? (
              <tr>
                <td colSpan={BRAND_CONFIG.showGradeMode === 2 ? 8 : 9} className="py-20 text-center text-gray-400">
                  Loading Report...
                </td>
              </tr>
            ) : filteredStats.length === 0 ? (
              <tr>
                <td colSpan={BRAND_CONFIG.showGradeMode === 2 ? 8 : 9} className="py-20 text-center text-gray-400">
                  ไม่พบข้อมูลพนักงาน
                </td>
              </tr>
            ) : (
              groups.map((group) => {
                const groupStats = groupedData[group.id] || [];
                if (groupStats.length === 0) return null;

                const isCollapsed = collapsedGroups[group.id];

                return (
                  <React.Fragment key={group.id}>
                    {/* Collapsible Section Header Row */}
                    {groupMode !== "NONE" && (
                      <TableGroupRow
                        group={group}
                        count={groupStats.length}
                        isCollapsed={isCollapsed}
                        onToggle={() => toggleGroup(group.id)}
                      />
                    )}

                    {/* Highly performant list of single rows */}
                    {(groupMode === "NONE" || !isCollapsed) &&
                      groupStats.map((stat, idx) => {
                        const user = userMap.get(stat.userId);
                        if (!user) return null;

                        return (
                          <EmployeeRow
                            key={stat.userId}
                            stat={stat}
                            user={user}
                            index={idx}
                            activeStatFilter={activeStatFilter}
                            sortDirection={sortDirection}
                            getGrade={getGrade}
                            onUserClick={onUserClick}
                            currentMonth={currentMonth}
                            workingDaysCount={workingDaysCount}
                            lateViewMode={lateViewMode}
                            otViewMode={otViewMode}
                            hpViewMode={hpViewMode}
                            snapshots={snapshots}
                          />
                        );
                      })}
                  </React.Fragment>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DashboardTable;
export type { UserStat, DashboardTableProps };
