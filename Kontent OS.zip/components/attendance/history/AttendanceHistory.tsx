import React from 'react';
import { LeaveType } from '../../../types/attendance';
import MyRequestHistory from './MyRequestHistory'; 
import LeaveRequestModal from '../leave-request/LeaveRequestModal'; 
import { useAttendanceHistoryEngine } from './useAttendanceHistoryEngine';
import AttendanceFilters from './subcomponents/AttendanceFilters';
import AttendanceTable from './subcomponents/AttendanceTable';
import AttendanceProofModal from './subcomponents/AttendanceProofModal';
import { useMasterData } from '../../../hooks/useMasterData';

interface AttendanceHistoryProps {
    userId: string;
    highlightedDate?: string | null;
    onClearHighlight?: () => void;
}

const AttendanceHistory: React.FC<AttendanceHistoryProps> = ({ userId, highlightedDate, onClearHighlight }) => {
    const {
        page,
        setPage,
        filters,
        isFetching,
        historyLogs,
        totalCount,
        totalPages,
        targetUser,
        myRequests,
        fetchRequestsForRange,
        isLoadingHistorical,
        handleFilterChange,
        resetFilters,
        viewProofUrl,
        setViewProofUrl,
        resubmitLog,
        setResubmitLog,
        isResubmitOpen,
        setIsResubmitOpen,
        handleResubmit,
        handleResubmitSubmit,
        fetchData,
        isLate,
        getProofUrl,
        getLocationDisplay,
        getWorkHours,
        getStatusConfig,
        holidays,
        exceptions,
        PAGE_SIZE
    } = useAttendanceHistoryEngine(userId, highlightedDate);
    const { masterOptions } = useMasterData();

    return (
        <div className="space-y-8">
            {/* --- SECTION 1: REQUESTS (คำขอต่างๆ) --- */}
            <div className="animate-in fade-in slide-in-from-top-4">
                 <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest mb-3 ml-1">
                     รายการคำขอ (Requests)
                 </h3>
                 <MyRequestHistory 
                     requests={myRequests} 
                     fetchRequestsForRange={fetchRequestsForRange}
                     isLoadingHistorical={isLoadingHistorical}
                 />
            </div>

            {/* --- SECTION 2: ATTENDANCE LOGS (ประวัติเวลา) --- */}
            <div className="space-y-4">
                <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest ml-1">
                    บันทึกเวลา (Time Logs)
                </h3>

                {/* --- Filter Bar --- */}
                <AttendanceFilters 
                    filters={filters}
                    onFilterChange={handleFilterChange}
                    onReset={resetFilters}
                    onRefresh={fetchData}
                    isFetching={isFetching}
                />

                {/* --- Data Table --- */}
                <AttendanceTable 
                    isFetching={isFetching}
                    historyLogs={historyLogs}
                    targetUser={targetUser}
                    isLate={isLate}
                    getProofUrl={getProofUrl}
                    getLocationDisplay={getLocationDisplay}
                    getWorkHours={getWorkHours}
                    getStatusConfig={getStatusConfig}
                    holidays={holidays}
                    exceptions={exceptions}
                    onResubmit={handleResubmit}
                    onViewProof={setViewProofUrl}
                    totalCount={totalCount}
                    page={page}
                    totalPages={totalPages}
                    onPageChange={setPage}
                    pageSize={PAGE_SIZE}
                    highlightedDate={highlightedDate}
                    onClearHighlight={onClearHighlight}
                    requests={myRequests}
                />

                {/* Proof Modal */}
                <AttendanceProofModal 
                    viewProofUrl={viewProofUrl}
                    onClose={() => setViewProofUrl(null)}
                />
                
                {/* Resubmit Modal */}
                <LeaveRequestModal 
                    isOpen={isResubmitOpen}
                    onClose={() => { setIsResubmitOpen(false); setResubmitLog(null); }}
                    onSubmit={handleResubmitSubmit}
                    masterOptions={masterOptions}
                    initialDate={resubmitLog ? new Date(resubmitLog.date) : undefined}
                    initialReason={resubmitLog?.note ? resubmitLog.note.replace(/\[.*?\]/g, '').trim() : ''}
                    fixedType={(() => {
                        if (!resubmitLog) return undefined;
                        // Check rejection/provisional tags first
                        if (resubmitLog.note?.includes('[REJECTED GPS_SPOOF_APPEAL]') || resubmitLog.note?.includes('[REJECTED_GPS_SPOOF_APPEAL]')) return 'GPS_SPOOF_APPEAL';
                        if (resubmitLog.note?.includes('[REJECTED OUT_OF_RANGE_CHECKOUT]')) return 'OUT_OF_RANGE_CHECKOUT';
                        if (resubmitLog.note?.includes('[PROVISIONAL_WFH]')) return 'WFH';
                        if (resubmitLog.note?.includes('[PROVISIONAL_ONSITE]')) return 'ONSITE';
                        // Determine the correct correction type based on missing times
                        if (!resubmitLog.checkInTime && !resubmitLog.checkOutTime) return 'FORGOT_BOTH';
                        if (!resubmitLog.checkInTime) return 'FORGOT_CHECKIN';
                        if (!resubmitLog.checkOutTime) return 'FORGOT_CHECKOUT';
                        return 'LATE_ENTRY'; // Fallback for other action required cases
                    })() as LeaveType}
                />
            </div>
        </div>
    );
};

export default AttendanceHistory;
