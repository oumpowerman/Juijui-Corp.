import { useState, useEffect, useMemo, useCallback } from 'react';
import { AttendanceLog, LeaveType, LeaveRequest } from '../../../types/attendance';
import { useAttendanceHistory } from '../../../hooks/attendance/useAttendanceHistory';
import { useLeaveRequests } from '../../../hooks/useLeaveRequests'; 
import { useUserSession } from '../../../context/UserSessionContext';
import { supabase } from '../../../lib/supabase';
import { format, isSameDay, isBefore, startOfDay, eachDayOfInterval, parseISO, isFuture } from 'date-fns';
import startOfMonth from 'date-fns/startOfMonth';
import endOfMonth from 'date-fns/endOfMonth';
import { checkIsLate, parseAttendanceMetadata } from '../../../lib/attendanceUtils';
import { useMasterDataContext } from '../../../context/MasterDataContext';
import { isWorkingDay, isUserOnLeave } from '../../../utils/judgeUtils';
import { AnnualHoliday } from '../../../types';
import { Clock, CheckCircle2, XCircle, Calendar, HelpCircle, Loader2, AlertTriangle } from 'lucide-react';

const PAGE_SIZE = 15;

export const useAttendanceHistoryEngine = (userId: string, highlightedDate?: string | null) => {
    const [page, setPage] = useState(1);
    const [filters, setFilters] = useState<any>({
        startDate: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
        endDate: format(endOfMonth(new Date()), 'yyyy-MM-dd'),
        workType: 'ALL'
    });

    useEffect(() => {
        if (highlightedDate) {
            const dateObj = parseISO(highlightedDate);
            if (!isNaN(dateObj.getTime())) {
                const startOfHighlightMonth = format(startOfMonth(dateObj), 'yyyy-MM-dd');
                const endOfHighlightMonth = format(endOfMonth(dateObj), 'yyyy-MM-dd');
                
                setFilters((prev: any) => ({
                    ...prev,
                    startDate: startOfHighlightMonth,
                    endDate: endOfHighlightMonth,
                    workType: 'ALL' // Reset workType filter to make sure the target row isn't filtered out
                }));
            }
        }
    }, [highlightedDate]);

    const { getAttendanceLogs, isHistoryLoading: isFetching } = useAttendanceHistory(userId);
    const { allUsers } = useUserSession();
    const { requests, submitRequest, fetchRequestsForRange, isLoadingHistorical } = useLeaveRequests({ id: userId } as any);

    const targetUser = useMemo(() => allUsers.find(u => u.id === userId), [allUsers, userId]);

    const { annualHolidays: holidays, calendarExceptions: exceptions } = useMasterDataContext();

    // Data State
    const [historyLogs, setHistoryLogs] = useState<AttendanceLog[]>([]);
    const [totalCount, setTotalCount] = useState(0);

    const fetchData = useCallback(async () => {
        // 1. Generate all days in the filter range first to calculate dates interval
        const start = parseISO(filters.startDate);
        const end = parseISO(filters.endDate);
        const allDays = eachDayOfInterval({ start, end });

        // Fetch logs from DB only within the selected date range to minimize network and database load
        const dbFilters = {
            startDate: filters.startDate,
            endDate: filters.endDate,
            workType: 'ALL'
        };
        const maxLogsNeeded = Math.max(100, allDays.length + 10);
        const { data: dbLogs, aborted } = await getAttendanceLogs(1, maxLogsNeeded, dbFilters);
        
        if (aborted) {
            return;
        }
        
        // 2. Map existing logs by date for O(1) fast lookup
        const logMap = new Map<string, AttendanceLog>();
        dbLogs.forEach(log => {
            const dateStr = format(new Date(log.date), 'yyyy-MM-dd');
            logMap.set(dateStr, log);
        });

        // 3. Define basic structure for calendar-first pagination (Active days metadata)
        interface ActiveDayInfo {
            date: Date;
            dateStr: string;
            existingLog?: AttendanceLog;
            virtualStatus?: 'ABSENT' | 'LEAVE' | 'HOLIDAY' | 'NOT_STARTED' | 'PENDING_VERIFY';
            virtualWorkType?: string;
        }

        const activeDays: ActiveDayInfo[] = [];

        for (const date of allDays) {
            const dateStr = format(date, 'yyyy-MM-dd');
            const existingLog = logMap.get(dateStr);

            if (existingLog) {
                activeDays.push({ date, dateStr, existingLog });
            } else {
                // Determine virtual status and workType
                const isWorkDay = isWorkingDay(date, holidays, exceptions, targetUser || null);
                const leaveCheck = isUserOnLeave(dateStr, requests);
                const isPast = !isFuture(date) && !isSameDay(date, new Date());

                let status: 'ABSENT' | 'LEAVE' | 'HOLIDAY' | 'NOT_STARTED' | 'PENDING_VERIFY' = 'ABSENT';
                let workType = 'OFFICE';
                
                if (leaveCheck.onLeave) {
                    status = leaveCheck.status === 'PENDING' ? 'PENDING_VERIFY' : 'LEAVE';
                    workType = 'LEAVE';
                } else {
                    const activeWorkRequest = requests.find((req: any) => {
                        if (req.userId !== userId || (req.status !== 'APPROVED' && req.status !== 'PENDING')) return false;
                        if (req.type !== 'WFH' && req.type !== 'ONSITE') return false;
                        const startStr = format(new Date(req.startDate), 'yyyy-MM-dd');
                        const endStr = format(new Date(req.endDate), 'yyyy-MM-dd');
                        return dateStr >= startStr && dateStr <= endStr;
                    });

                    if (activeWorkRequest) {
                        workType = activeWorkRequest.type;
                    }

                    if (!isWorkDay) {
                        status = 'HOLIDAY';
                        workType = 'OFFICE'; // Default
                    } else if (!isPast) {
                        status = 'NOT_STARTED'; // Skip future/unstarted
                        workType = 'OFFICE';
                    }
                }

                // Filter out holidays/weekends/unstarted from the active log list to match previous logic
                if (status === 'HOLIDAY' || status === 'NOT_STARTED') {
                    continue;
                }

                activeDays.push({
                    date,
                    dateStr,
                    virtualStatus: status,
                    virtualWorkType: workType
                });
            }
        }

        // 4. Perform client-side workType filtering on the active days metadata list
        let filteredActiveDays = activeDays;
        if (filters.workType && filters.workType !== 'ALL') {
            filteredActiveDays = activeDays.filter(day => {
                if (day.existingLog) {
                    return day.existingLog.workType === filters.workType;
                } else {
                    return day.virtualWorkType === filters.workType;
                }
            });
        }

        // 5. Sort descending by date (latest date first)
        filteredActiveDays.sort((a, b) => b.date.getTime() - a.date.getTime());

        setTotalCount(filteredActiveDays.length);

        // If highlightedDate is provided, let's find the page and make sure page is set correctly
        if (highlightedDate) {
            const targetIndex = filteredActiveDays.findIndex(day => day.dateStr === highlightedDate);
            if (targetIndex !== -1) {
                const targetPage = Math.floor(targetIndex / PAGE_SIZE) + 1;
                if (page !== targetPage) {
                    setPage(targetPage);
                    return; // Return early, the state update will trigger another fetchData call with the correct page.
                }
            }
        }
        
        // 6. Paginate the calendar metadata list first to identify target 15 days
        const startIndex = (page - 1) * PAGE_SIZE;
        const pageActiveDays = filteredActiveDays.slice(startIndex, startIndex + PAGE_SIZE);

        // 7. Perform Gap-Filling ONLY for the 15 active days of the current page
        const pagedData: AttendanceLog[] = pageActiveDays.map(day => {
            if (day.existingLog) {
                return day.existingLog;
            }

            return {
                id: `virtual-${day.dateStr}`,
                userId: userId,
                date: day.dateStr,
                checkInTime: null,
                checkOutTime: null,
                status: day.virtualStatus || 'ABSENT',
                workType: day.virtualWorkType || 'OFFICE',
                note: '[VIRTUAL] Missing log',
                locationName: undefined
            } as AttendanceLog;
        });

        setHistoryLogs(pagedData);

    }, [getAttendanceLogs, page, filters, holidays, exceptions, targetUser, requests, userId, highlightedDate]);



    useEffect(() => {
        fetchData();

        // Real-time Subscription for this user's logs
        const channel = supabase.channel(`attendance-history-realtime-${userId}`)
            .on('postgres_changes', { 
                event: '*', 
                schema: 'public', 
                table: 'attendance_logs',
                filter: `user_id=eq.${userId}`
            }, () => {
                fetchData();
            })
            .subscribe();

        return () => {
            supabase.removeChannel(channel);
        };
    }, [fetchData, userId]); 

    const [viewProofUrl, setViewProofUrl] = useState<string | null>(null);
    
    // Re-submit State
    const [resubmitLog, setResubmitLog] = useState<AttendanceLog | null>(null);
    const [isResubmitOpen, setIsResubmitOpen] = useState(false);

    // Filter MY requests for the separate component
    const myRequests = useMemo(() => {
        return requests
            .filter(r => r.userId === userId)
            .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    }, [requests, userId]);

    const handleFilterChange = (key: string, value: string) => {
        setFilters((prev: any) => ({ ...prev, [key]: value }));
        setPage(1); 
    };

    const resetFilters = () => {
        setFilters({
            startDate: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
            endDate: format(endOfMonth(new Date()), 'yyyy-MM-dd'),
            workType: 'ALL'
        });
        setPage(1);
    };

    const totalPages = Math.ceil(totalCount / PAGE_SIZE);

    const { masterOptions } = useMasterDataContext();
    const startTimeStr = masterOptions.find(o => o.type === 'WORK_CONFIG' && o.key === 'START_TIME')?.label || '10:00';
    const lateBufferMinutes = parseInt(masterOptions.find(o => o.type === 'WORK_CONFIG' && o.key === 'LATE_BUFFER')?.label || '0');

    const multipleShifts = useMemo(() => {
        const shiftsEnabledOpt = masterOptions.find(o => o.type === 'WORK_CONFIG' && o.key === 'MULTIPLE_SHIFTS_ENABLED');
        const shiftsListOpt = masterOptions.find(o => o.type === 'WORK_CONFIG' && o.key === 'MULTIPLE_SHIFTS_LIST');
        return {
            enabled: shiftsEnabledOpt?.label === 'true',
            shiftsList: shiftsListOpt?.label || ''
        };
    }, [masterOptions]);

    // Helpers
    const isLate = useCallback((log: AttendanceLog) => {
        if (!log.checkInTime) return false;
        return checkIsLate(log.checkInTime, startTimeStr, lateBufferMinutes, log.note, multipleShifts);
    }, [startTimeStr, lateBufferMinutes, multipleShifts]);

    const getProofUrl = useCallback((log: AttendanceLog) => {
        if (log.attachmentUrls && log.attachmentUrls.length > 0) {
            return log.attachmentUrls[0];
        }
        return null;
    }, []);

    const getLocationDisplay = useCallback((log: AttendanceLog) => {
        const isVirtualLeave = !log.checkInTime || log.workType === 'LEAVE';

        if (isVirtualLeave && (log.workType === 'LEAVE' || log.status === 'LEAVE' || log.status === 'PENDING_VERIFY')) {
            const checkDate = new Date(log.date);
            checkDate.setHours(12, 0, 0, 0);

            const match = requests.find((req: any) => {
                if (req.userId !== userId) return false;
                if (req.status === 'REJECTED') return false;
                
                const LEAVE_TYPES = ['SICK', 'VACATION', 'PERSONAL', 'EMERGENCY', 'UNPAID'];
                if (!LEAVE_TYPES.includes(req.type)) return false;

                const start = new Date(req.startDate);
                start.setHours(0, 0, 0, 0);
                const end = new Date(req.endDate);
                end.setHours(23, 59, 59, 999);

                return checkDate >= start && checkDate <= end;
            });

            if (match) {
                switch (match.type) {
                    case 'SICK':
                        return 'ลาป่วย (Sick Leave)';
                    case 'VACATION':
                        return 'ลาพักร้อน (Vacation Leave)';
                    case 'PERSONAL':
                        return 'ลากิจ (Personal Leave)';
                    case 'EMERGENCY':
                        return 'ลาฉุกเฉิน (Emergency Leave)';
                    case 'UNPAID':
                        return 'ลาไม่รับค่าจ้าง (Unpaid Leave)';
                    default:
                        return `ลาประเภท ${match.type}`;
                }
            }
            // Fallback for virtual leave logs without an explicit request object found in range
            return 'การลา (Leave)';
        }

        if (log.locationName) return log.locationName;
        const meta = parseAttendanceMetadata(log.note);
        if (meta.locationName) return meta.locationName;
        
        if (log.workType === 'WFH') {
            return 'ทำงานที่บ้าน (WFH)';
        }
        if (log.workType === 'ONSITE' || log.workType === 'SITE') {
            return 'ปฏิบัติงานนอกสถานที่ (On-site)';
        }
        
        return meta.location ? `${meta.location.lat.toFixed(4)}, ${meta.location.lng.toFixed(4)}` : '-';
    }, [requests, userId]);

    const getWorkHours = useCallback((log: AttendanceLog) => {
        if (!log.checkInTime || !log.checkOutTime) return '-';
        const diffMs = log.checkOutTime.getTime() - log.checkInTime.getTime();
        const hrs = Math.floor(diffMs / (1000 * 60 * 60));
        const mins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        return `${hrs}h ${mins}m`;
    }, []);
    
    // --- STATUS BADGE LOGIC (Updated for 100% Coverage) ---
    const getStatusConfig = useCallback((log: AttendanceLog, userStartDate?: Date) => {
        if (log.status === 'ABSENT' && userStartDate && isBefore(startOfDay(new Date(log.date)), startOfDay(userStartDate))) {
            return { label: 'ยังไม่เริ่มงาน', color: 'bg-gray-100 text-gray-500 border-gray-200', icon: HelpCircle };
        }

        const noteText = log.note || '';
        const isProvisionalForgot = noteText.includes('[PROVISIONAL_FORGOT_CHECKIN]');
        const isProvisionalWfh = noteText.includes('[PROVISIONAL_WFH]');
        const isProvisionalOnsite = noteText.includes('[PROVISIONAL_ONSITE]');
        const isProvisionalLate = noteText.includes('[APPEAL_PENDING]') || noteText.includes('[PROVISIONAL_LATE_ENTRY]');
        const isEarlyLeave = noteText.includes('[REJECTED EARLY_LEAVE_APPEAL]') || noteText.includes('[ACCEPT_PENALTY]') || noteText.includes('[APPROVED EARLY_LEAVE_APPEAL]') || noteText.includes('[APPROVED EARLY_LEAVE]');

        if (isEarlyLeave) {
            return { label: 'กลับก่อนเวลา', color: 'bg-orange-100 text-orange-700 border-orange-200', icon: Clock };
        }

        if (log.status === 'WORKING') {
            if (isProvisionalForgot) {
                return { label: 'กำลังทำงาน (จำลองลืมลงเวลา)', color: 'bg-amber-100 text-amber-700 border-amber-200', icon: Loader2 };
            }
            if (isProvisionalWfh) {
                return { label: 'กำลังทำงาน (WFH จำลอง)', color: 'bg-blue-100 text-blue-700 border-blue-200', icon: Loader2 };
            }
            if (isProvisionalOnsite) {
                return { label: 'กำลังทำงาน (On-site จำลอง)', color: 'bg-orange-100 text-orange-700 border-orange-200', icon: Loader2 };
            }
            if (isProvisionalLate) {
                return { label: 'กำลังทำงาน (แจ้งเข้าสายจำลอง)', color: 'bg-violet-100 text-violet-700 border-violet-200', icon: Loader2 };
            }
        }

        if ((log.status === 'COMPLETED' || log.status === 'LATE' || log.status === 'PENDING_VERIFY') && isProvisionalForgot) {
            return { label: 'รออนุมัติเข้างาน (ลืมลงเวลา)', color: 'bg-amber-100 text-amber-700 border-amber-200', icon: Clock };
        }

        if ((log.status === 'COMPLETED' || log.status === 'LATE' || log.status === 'PENDING_VERIFY') && isProvisionalLate) {
            return { label: 'รออนุมัติเข้างาน (ขอเข้าสาย)', color: 'bg-violet-100 text-violet-700 border-violet-200', icon: Clock };
        }

        if ((log.status === 'COMPLETED' || log.status === 'LATE' || log.status === 'PENDING_VERIFY') && isProvisionalWfh) {
            return { label: 'รออนุมัติเข้างาน (WFH จำลอง)', color: 'bg-blue-100 text-blue-700 border-blue-200', icon: Clock };
        }

        if ((log.status === 'COMPLETED' || log.status === 'LATE' || log.status === 'PENDING_VERIFY') && isProvisionalOnsite) {
            return { label: 'รออนุมัติเข้างาน (On-site จำลอง)', color: 'bg-orange-100 text-orange-700 border-orange-200', icon: Clock };
        }

        switch (log.status) {
            case 'APPEAL':
                return { label: 'อยู่ระหว่างการอุทธรณ์', color: 'bg-violet-100 text-violet-700 border-violet-200', icon: Clock };
            case 'COMPLETED':
            case 'ON_TIME': // In case we use specific status
                return { label: 'ปกติ', color: 'bg-green-100 text-green-700 border-green-200', icon: CheckCircle2 };
            case 'LATE':
                return { label: 'สาย', color: 'bg-yellow-100 text-yellow-700 border-yellow-200', icon: Clock };
            case 'ABSENT':
            case 'NO_SHOW':
                return { label: 'ขาดงาน', color: 'bg-red-100 text-red-700 border-red-200', icon: XCircle };
            case 'LEAVE':
                return { label: 'ลา', color: 'bg-blue-100 text-blue-700 border-blue-200', icon: Calendar };
            case 'PENDING_VERIFY':
                return { label: 'รอตรวจสอบ', color: 'bg-orange-100 text-orange-700 border-orange-200 animate-pulse', icon: HelpCircle };
            case 'ACTION_REQUIRED':
                return { label: 'แก้ไขด่วน', color: 'bg-red-500 text-white border-red-600 animate-bounce', icon: AlertTriangle };
            case 'WORKING':
                return { label: 'กำลังทำงาน', color: 'bg-indigo-100 text-indigo-700 border-indigo-200', icon: Loader2 };
            default:
                return { label: log.status, color: 'bg-gray-100 text-gray-600 border-gray-200', icon: Calendar };
        }
    }, []);

    const handleResubmit = useCallback((log: AttendanceLog) => {
        setResubmitLog(log);
        setIsResubmitOpen(true);
    }, []);
    
    const handleResubmitSubmit = useCallback(async (type: LeaveType, start: Date, end: Date, reason: string, files?: File[]) => {
        const success = await submitRequest(type, start, end, reason, files);
        if (success) {
            fetchData(); 
        }
        return success;
    }, [submitRequest, fetchData]);

    return {
        page,
        setPage,
        filters,
        isFetching,
        historyLogs,
        totalCount,
        totalPages,
        targetUser,
        myRequests,
        fetchRequestsForRange,
        isLoadingHistorical,
        handleFilterChange,
        resetFilters,
        viewProofUrl,
        setViewProofUrl,
        resubmitLog,
        setResubmitLog,
        isResubmitOpen,
        setIsResubmitOpen,
        handleResubmit,
        handleResubmitSubmit,
        fetchData,
        isLate,
        getProofUrl,
        getLocationDisplay,
        getWorkHours,
        getStatusConfig,
        holidays,
        exceptions,
        PAGE_SIZE
    };
};
