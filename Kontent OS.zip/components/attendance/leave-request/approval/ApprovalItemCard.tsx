import React from 'react';
import { motion } from 'framer-motion';
import { 
    CheckCircle2, XCircle, Clock, AlertTriangle, MapPin, 
    Calendar, ExternalLink, Moon 
} from 'lucide-react';
import { format } from 'date-fns';
import { LeaveRequest } from '../../../../types/attendance';
import { getWorkingDaysDifference } from '../../../../lib/attendanceUtils';
import { parseReason, ParsedReason } from '../request-detail/utils';
import { getRegistryItem } from '../../../../constants/attendanceRegistry';
import CompanyBadge from '../../../common/CompanyBadge';

const LEAVE_EMOJI_MAP: Record<string, string> = {
    SICK: '🤒',
    VACATION: '🌴',
    PERSONAL: '💼',
    EMERGENCY: '🚨',
    UNPAID: '💸',
    LATE_ENTRY: '⏰',
    OVERTIME: '🌙',
    FORGOT_CHECKIN: '🤷‍♂️',
    FORGOT_CHECKOUT: '🤦‍♂️',
    FORGOT_BOTH: '🫣',
    WFH: '🏠',
    ONSITE: '📍',
    OUT_OF_RANGE_CHECKOUT: '🗺️',
    GPS_SPOOF_APPEAL: '📡',
    GPS_SPOOF_OUT_APPEAL: '📡',
    EARLY_LEAVE: '🏃',
};

export interface ApprovalItemCardProps {
    request: LeaveRequest;
    onApprove: (req: LeaveRequest, customStartTime?: string) => Promise<void> | void;
    onRejectClick: (id: string) => void;
    onViewDetail: (req: LeaveRequest) => void;
    annualHolidays: any;
    calendarExceptions: any;
    isHighlighted?: boolean;
}

export const getCardStyle = (type: string) => {
    const item = getRegistryItem(type);
    
    let category: 'LEAVE' | 'LATE_FORGOT' | 'OT' = 'LEAVE';
    if (type === 'OVERTIME') {
        category = 'OT';
    } else if (item?.category === 'CORRECTION' || type === 'GPS_SPOOF_APPEAL') {
        category = 'LATE_FORGOT';
    }

    if (category === 'OT') {
        return {
            bg: 'bg-indigo-100/60 hover:bg-indigo-100/80',
            border: 'border-indigo-100/70 hover:border-indigo-200',
            accent: 'bg-indigo-500'
        };
    } else if (category === 'LATE_FORGOT') {
        return {
            bg: 'bg-amber-100/60 hover:bg-amber-100/80',
            border: 'border-amber-100/70 hover:border-amber-200',
            accent: 'bg-amber-500'
        };
    } else {
        return {
            bg: 'bg-rose-100/60 hover:bg-rose-100/80',
            border: 'border-rose-100/70 hover:border-rose-200',
            accent: 'bg-rose-500'
        };
    }
};

const isTimeDifferent = (time1: string | null, time2: string | null): boolean => {
    if (!time1 || !time2) return false;
    const clean = (t: string) => t.replace(/[^a-zA-Z0-9:]/g, '').trim();
    return clean(time1) !== clean(time2);
};

// 1. ApprovalCardHeader
export const ApprovalCardHeader: React.FC<{ request: LeaveRequest; cardStyle: any }> = ({ request, cardStyle }) => {
    return (
        <div className="shrink-0 relative">
            {request.user?.avatarUrl ? (
                <img 
                    src={request.user.avatarUrl} 
                    className="w-14 h-14 rounded-2xl object-cover border-2 border-white shadow-md" 
                    referrerPolicy="no-referrer"
                    alt={request.user?.name}
                />
            ) : (
                <div className="w-14 h-14 rounded-2xl bg-indigo-50 flex items-center justify-center font-bold text-indigo-400 border-2 border-white shadow-md">
                    {request.user?.name?.charAt(0)}
                </div>
            )}
            <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-white flex items-center justify-center shadow-sm ${
                request.status === 'APPROVED' ? 'bg-green-500' : 
                request.status === 'REJECTED' ? 'bg-red-500' : 
                'bg-orange-400'
            }`}>
                {request.status === 'APPROVED' && <CheckCircle2 className="w-3 h-3 text-white" />}
                {request.status === 'REJECTED' && <XCircle className="w-3 h-3 text-white" />}
                {request.status === 'PENDING' && <Clock className="w-3 h-3 text-white" />}
            </div>
        </div>
    );
};

// 2. ApprovalCardDetails
interface ApprovalCardDetailsProps {
    request: LeaveRequest;
    parsed: ParsedReason;
    cardStyle: any;
    annualHolidays: any;
    calendarExceptions: any;
}

export const ApprovalCardDetails: React.FC<ApprovalCardDetailsProps> = ({ 
    request, parsed, cardStyle, annualHolidays, calendarExceptions 
}) => {
    const renderReason = (parsedReason: ParsedReason) => {
        return (
            <p className="text-sm text-gray-700 bg-white p-3.5 rounded-2xl border border-black/5 italic leading-relaxed shadow-inner">
                "{parsedReason.cleanReason || 'ไม่ได้ระบุเหตุผลเพิ่มเติม'}"
            </p>
        );
    };

    return (
        <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-x-3 gap-y-2 mb-2">
                <div className="flex flex-col justify-center">
                    <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="font-bold text-gray-800 text-base leading-tight">
                            {request.user?.name || 'Unknown'}
                        </h4>
                        <CompanyBadge company={request.user?.company} companyId={request.user?.companyId} size="xs" />
                    </div>
                    {request.user?.position && (
                        <span className="text-[11px] text-slate-500 font-semibold tracking-wide mt-0.5 leading-none">
                            {request.user.position}
                        </span>
                    )}
                </div>
                
                {/* Parsed Badges */}
                {parsed.isProvisionalWfh && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-sky-50 text-sky-700 border-sky-200/60 flex items-center gap-1 animate-pulse shadow-sm">
                        <AlertTriangle className="w-3 h-3 text-sky-500" /> WFH แบบจำลอง (รออนุมัติสิทธิ์)
                    </span>
                )}

                {parsed.isProvisionalOnsite && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-orange-50 text-orange-700 border-orange-200/60 flex items-center gap-1 animate-pulse shadow-sm">
                        <AlertTriangle className="w-3 h-3 text-orange-500" /> On-site แบบจำลอง (รออนุมัติสิทธิ์)
                    </span>
                )}

                {parsed.isProvisionalForgotCheckin && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-amber-50 text-amber-700 border-amber-200/60 flex items-center gap-1 animate-pulse shadow-sm">
                        <AlertTriangle className="w-3 h-3 text-amber-500" /> ลืมลงเวลาแบบจำลอง (รออนุมัติสิทธิ์)
                    </span>
                )}

                {parsed.isProvisionalLate && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-violet-50 text-violet-700 border-violet-200/60 flex items-center gap-1 animate-pulse shadow-sm">
                        <AlertTriangle className="w-3 h-3 text-violet-500" /> เข้าสายแบบจำลอง (รออนุมัติสิทธิ์)
                    </span>
                )}

                {parsed.isProvisionalCheckout && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-rose-50 text-rose-700 border-rose-200/60 flex items-center gap-1 animate-pulse shadow-sm">
                        <AlertTriangle className="w-3 h-3 text-rose-500" /> ลืมลงเวลาออกงานจำลอง (รออนุมัติสิทธิ์)
                    </span>
                )}

                {parsed.isProvisionalGps && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-purple-50 text-purple-700 border-purple-200/60 flex items-center gap-1 animate-pulse shadow-sm">
                        <AlertTriangle className="w-3 h-3 text-purple-500" /> 📍 ลงเวลาแบบจำลอง (อุทธรณ์พิกัด GPS)
                    </span>
                )}

                {parsed.isLateSubmission && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-amber-100 text-amber-700 border-amber-200/60 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" /> ส่งคำขอช้ากว่ากำหนด
                    </span>
                )}

                {parsed.isLocationMismatch && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-rose-100 text-rose-700 border-rose-200/60 flex items-center gap-1 animate-pulse">
                        <MapPin className="w-3 h-3" /> พิกัดภายนอกพื้นที่ทำงาน
                    </span>
                )}

                {parsed.forgotCheckoutPenalty && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-orange-100 text-orange-700 border-orange-200/60 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" /> ลืมเช็คเอาท์ (ระบบปรับลดคะแนน)
                    </span>
                )}

                {parsed.targetShift && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-purple-100 text-purple-700 border-purple-200/60 flex items-center gap-1 shadow-sm">
                        <Clock className="w-3 h-3 text-purple-500" /> 🎯 กะงาน: {parsed.targetShift} น.
                    </span>
                )}

                {parsed.approvedTime && isTimeDifferent(parsed.time, parsed.approvedTime) ? (
                    <>
                        <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-gray-100 text-gray-500 border-gray-200 flex items-center gap-1">
                            <Clock className="w-3 h-3 text-gray-400" /> เวลาที่ขอ: {parsed.time?.includes('-') ? parsed.time.replace('-', ' - ') : parsed.time} น.
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-emerald-50 text-emerald-700 border-emerald-200/60 flex items-center gap-1 animate-pulse">
                            <CheckCircle2 className="w-3 h-3 text-emerald-500" /> อนุมัติแก้เป็น: {parsed.approvedTime.includes('-') ? parsed.approvedTime.replace('-', ' - ') : parsed.approvedTime} น.
                        </span>
                    </>
                ) : (
                    parsed.time && (
                        <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-indigo-100 text-indigo-700 border-indigo-200/60 flex items-center gap-1">
                            <Clock className="w-3 h-3" /> เวลา: {parsed.time?.includes('-') ? parsed.time.replace('-', ' - ') : parsed.time} น.
                        </span>
                    )
                )}

                {parsed.actualCheckInTime && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-teal-50 text-teal-700 border-teal-200/60 flex items-center gap-1 shadow-sm">
                        <Clock className="w-3 h-3 text-teal-500" /> เวลาสแกนจริง: {parsed.actualCheckInTime} น.
                    </span>
                )}

                {parsed.otHours && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-indigo-100 text-indigo-700 border-indigo-200/60 flex items-center gap-1 animate-pulse">
                        <Moon className="w-3 h-3 text-indigo-500" /> จำนวน: {parsed.otHours} ชม.
                    </span>
                )}

                {parsed.isFixedOt && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-indigo-100 text-indigo-700 border-indigo-200/60 flex items-center gap-1 animate-pulse">
                        <Moon className="w-3 h-3 text-indigo-500" /> เหมาจ่าย (Lump-sum)
                    </span>
                )}

                {parsed.remoteType && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-emerald-50 text-emerald-700 border-emerald-200/60 flex items-center gap-1 shadow-sm">
                        🏠 ทำงานรีโมท: {parsed.remoteType}
                    </span>
                )}

                {parsed.distance && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-rose-50 text-rose-700 border-rose-200/60 flex items-center gap-1 shadow-sm">
                        <MapPin className="w-3 h-3 text-rose-500" /> ห่างพิกัดหลัก: {parsed.distance} กม.
                    </span>
                )}

                {parsed.linkId && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-indigo-50 text-indigo-700 border-indigo-200/60 flex items-center gap-1 shadow-sm">
                        🔗 ผูกคำขอร่วมกัน
                    </span>
                )}

                {request.isHalfDay && (
                    <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-indigo-50 text-indigo-700 border-indigo-200/60 flex items-center gap-1 shadow-sm">
                        ⏱️ ลาครึ่งวัน{(request.halfDaySession === 'AM' ? 'เช้า' : 'บ่าย')} (0.5 วัน)
                    </span>
                )}

                {/* Expiration Warning */}
                {request.status === 'PENDING' && ['LATE_ENTRY', 'FORGOT_CHECKIN', 'FORGOT_CHECKOUT', 'FORGOT_BOTH', 'OUT_OF_RANGE_CHECKOUT', 'GPS_SPOOF_APPEAL'].includes(request.type) && (
                    getWorkingDaysDifference(request.createdAt, new Date(), annualHolidays, calendarExceptions) >= 2 && (
                        <span className="text-[10px] px-2 py-0.5 rounded-lg font-bold border bg-red-100 text-red-700 border-red-200/60 flex items-center gap-1 animate-pulse">
                            <AlertTriangle className="w-3 h-3" /> ใกล้หมดอายุ
                        </span>
                    )
                )}

                <span className="text-[11px] text-slate-500 font-semibold bg-slate-50/80 px-2 py-0.5 rounded-md border border-slate-100 ml-auto font-mono">
                    {format(new Date(request.createdAt), 'd MMM HH:mm')}
                </span>
            </div>
            
            <div className="flex flex-wrap items-center gap-3 mb-4">
                {/* 1. Dynamic Date Badge (No Hardcoded Colors) */}
                {(() => {
                    const registryItem = getRegistryItem(request.type);
                    const bgClass = registryItem?.colors?.bg ? `${registryItem.colors.bg}/80` : 'bg-white/80';
                    const textClass = registryItem?.colors?.text || 'text-gray-700';
                    const borderClass = registryItem?.colors?.border ? `border-2 ${registryItem.colors.border}/50` : 'border border-black/5';
                    
                    return (
                        <div className={`flex items-center gap-2 text-xs font-bold px-3 py-1.5 rounded-full shadow-sm ${bgClass} ${textClass} ${borderClass}`}>
                            <Calendar className="w-3.5 h-3.5" />
                            {format(new Date(request.startDate), 'd MMM')} 
                            {new Date(request.startDate).getTime() !== new Date(request.endDate).getTime() && ` - ${format(new Date(request.endDate), 'd MMM yyyy')}`}
                        </div>
                    );
                })()}

                {/* 2. Primary Badge (Showing Request Type Label with Emoji) */}
                {(() => {
                    const registryItem = getRegistryItem(request.type);
                    if (!registryItem) return null;
                    
                    const emoji = LEAVE_EMOJI_MAP[request.type] || '📝'; 
                    
                    const bgClass = registryItem.colors?.bg ? `${registryItem.colors.bg}/95` : 'bg-slate-50';
                    const textClass = registryItem.colors?.text || 'text-slate-700';
                    const borderClass = registryItem.colors?.border ? `border-2 ${registryItem.colors.border}` : 'border border-slate-200';
                    
                    return (
                        <span className={`text-xs px-3.5 py-1.5 rounded-full font-extrabold shadow-sm flex items-center gap-1.5 ${bgClass} ${textClass} ${borderClass}`}>
                            <span>{emoji}</span>
                            <span>{registryItem.label}</span>
                        </span>
                    );
                })()}

                {(() => {
                    const attachments: string[] = [];
                    if (request.attachmentUrls && request.attachmentUrls.length > 0) {
                        attachments.push(...request.attachmentUrls);
                    }
                    if (parsed.proofUrl && !attachments.includes(parsed.proofUrl)) {
                        attachments.push(parsed.proofUrl);
                    }
                    const validAttachments = attachments.filter(Boolean);

                    if (validAttachments.length === 0) return null;

                    return (
                        <div className="flex flex-wrap gap-1.5">
                            {validAttachments.map((url, idx) => (
                                <a 
                                    key={idx}
                                    href={url} 
                                    target="_blank" 
                                    rel="noreferrer" 
                                    onClick={(e) => e.stopPropagation()}
                                    className="inline-flex items-center gap-1.5 text-[10px] bg-blue-100 text-blue-700 border border-blue-200/50 px-3 py-1.5 rounded-full font-bold hover:bg-blue-200 transition-colors cursor-pointer"
                                    id={`evidence-link-${request.id}-${idx}`}
                                >
                                    <ExternalLink className="w-3 h-3" /> 
                                    ดูหลักฐาน {validAttachments.length > 1 ? `(${idx + 1})` : ''}
                                </a>
                            ))}
                        </div>
                    );
                })()}
            </div>

            {renderReason(parsed)}
            
            {/* Rejection Reason Display */}
            {request.status === 'REJECTED' && request.rejectionReason && (
                <div className="mt-3 text-xs text-red-600 bg-red-50/50 p-3 rounded-2xl border border-red-100/50 flex gap-2">
                    <XCircle className="w-4 h-4 shrink-0" />
                    <div>
                        <span className="font-bold block mb-0.5">เหตุผลที่ปฏิเสธ:</span>
                        <p className="italic">"{request.rejectionReason}"</p>
                    </div>
                </div>
            )}
        </div>
    );
};
{/* 
// 3. ApprovalCardActions
interface ApprovalCardActionsProps {
    request: LeaveRequest;
    onApprove: (req: LeaveRequest, customStartTime?: string) => Promise<void> | void;
    onRejectClick: (id: string) => void;
}

export const ApprovalCardActions: React.FC<ApprovalCardActionsProps> = ({
    request, onApprove, onRejectClick
}) => {
    if (request.status !== 'PENDING') return null;

    const registryItem = getRegistryItem(request.type);
    const isTimeSpecific = registryItem?.rules?.isTimeSpecific ?? false;
    const isTimeApplicable = isTimeSpecific || ['FORGOT_CHECKIN', 'FORGOT_BOTH', 'LATE_ENTRY'].includes(request.type);

    if (isTimeApplicable) {
        const parsed = parseReason(request.reason);
        const requestTime = parsed.time;
        const formattedRequestTime = requestTime ? (requestTime.includes('-') ? requestTime.replace('-', ' - ') : requestTime) : '';
        return (
            <div className="flex flex-col sm:flex-row lg:flex-col gap-2 shrink-0 lg:w-44 lg:justify-center border-t lg:border-t-0 lg:border-l border-black/5 pt-4 lg:pt-0 lg:pl-6 mt-2 lg:mt-0" onClick={(e) => e.stopPropagation()}>
                <button 
                    onClick={(e) => { 
                        e.stopPropagation(); 
                        onApprove(request, 'DIRECT_APPROVE'); 
                    }}
                    className="flex-1 px-3 py-2.5 bg-green-500 hover:bg-green-600 text-white rounded-2xl text-[10px] font-bold shadow-lg shadow-green-100 transition-all active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
                    id={`approve-direct-btn-${request.id}`}
                >
                    <CheckCircle2 className="w-3.5 h-3.5" /> อนุมัติตามขอ{formattedRequestTime ? ` (${formattedRequestTime})` : ''}
                </button>
                <button 
                    onClick={(e) => { 
                        e.stopPropagation(); 
                        onApprove(request, 'ADJUST_TIME'); 
                    }}
                    className="flex-1 px-3 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-2xl text-[10px] font-bold shadow-lg shadow-amber-100 transition-all active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
                    id={`adjust-btn-${request.id}`}
                >
                    <Clock className="w-3.5 h-3.5" /> แก้ไขเวลา
                </button>
                <button 
                    onClick={(e) => { 
                        e.stopPropagation(); 
                        onRejectClick(request.id); 
                    }}
                    className="flex-1 px-3 py-2.5 bg-white border-2 border-red-100 text-red-500 hover:bg-red-50 rounded-2xl text-[10px] font-bold transition-all active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
                    id={`reject-btn-${request.id}`}
                >
                    <XCircle className="w-3.5 h-3.5" /> ปฏิเสธ
                </button>
            </div>
        );
    }

    return (
        <div className="flex flex-row lg:flex-col gap-2 shrink-0 lg:w-32 lg:justify-center border-t lg:border-t-0 lg:border-l border-black/5 pt-4 lg:pt-0 lg:pl-6 mt-2 lg:mt-0" onClick={(e) => e.stopPropagation()}>
            <button 
                onClick={(e) => { 
                    e.stopPropagation(); 
                    onApprove(request); 
                }}
                className="flex-1 px-4 py-3 bg-green-500 hover:bg-green-600 text-white rounded-2xl text-xs font-bold shadow-lg shadow-green-100 transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                id={`approve-btn-${request.id}`}
            >
                <CheckCircle2 className="w-4 h-4" /> อนุมัติ
            </button>
            <button 
                onClick={(e) => { 
                    e.stopPropagation(); 
                    onRejectClick(request.id); 
                }}
                className="flex-1 px-4 py-3 bg-white border-2 border-red-100 text-red-500 hover:bg-red-50 rounded-2xl text-xs font-bold transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                id={`reject-btn-${request.id}`}
            >
                <XCircle className="w-4 h-4" /> ปฏิเสธ
            </button>
        </div>
    );
};
*/}
// Main Composite component ApprovalItemCard
export const ApprovalItemCard = React.forwardRef<HTMLDivElement, ApprovalItemCardProps>(({
    request,
    onApprove,
    onRejectClick,
    onViewDetail,
    annualHolidays,
    calendarExceptions,
    isHighlighted
}, ref) => {
    const cardStyle = getCardStyle(request.type);
    const parsed = parseReason(request.reason);

    const cardRef = React.useRef<HTMLDivElement>(null);
    React.useImperativeHandle(ref, () => cardRef.current!);

    const [shouldGlow, setShouldGlow] = React.useState(isHighlighted);

    React.useEffect(() => {
        if (isHighlighted) {
            setShouldGlow(true);
            const timer = setTimeout(() => {
                setShouldGlow(false);
            }, 3000);
            return () => clearTimeout(timer);
        } else {
            setShouldGlow(false);
        }
    }, [isHighlighted]);

    React.useEffect(() => {
        if (isHighlighted && cardRef.current) {
            const timer = setTimeout(() => {
                cardRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 400);
            return () => clearTimeout(timer);
        }
    }, [isHighlighted]);

    return (
        <motion.div 
            ref={cardRef}
            layout
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: shouldGlow ? 1.03 : 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            whileHover={{ scale: shouldGlow ? 1.03 : 1.01 }}
            whileTap={{ scale: 0.99 }}
            transition={{
                type: "spring",
                stiffness: 380,
                damping: 35,
                mass: 0.8
            }}
            onClick={() => onViewDetail(request)}
            className={`${cardStyle.bg} ${cardStyle.border} p-5 rounded-3xl border shadow-sm hover:shadow-md transition-[background-color,border-color,box-shadow] relative overflow-hidden group cursor-pointer ${
                shouldGlow ? 'ring-4 ring-amber-400 ring-offset-2 shadow-amber-300/60 duration-500 animate-pulse' : 'duration-200'
            }`}
            id={`request-card-${request.id}`}
        >
            {/* Status Indicator Bar */}
            <div className={`absolute top-0 left-0 w-1.5 h-full ${
                request.status === 'APPROVED' ? 'bg-green-500' : 
                request.status === 'REJECTED' ? 'bg-red-500' : 
                `${cardStyle.accent} animate-pulse`
            }`}></div>

            <div className="flex flex-col lg:flex-row gap-6 justify-between">
                <div className="flex flex-col gap-4 flex-1">
                    <div className="flex gap-5">
                        <ApprovalCardHeader request={request} cardStyle={cardStyle} />
                        <ApprovalCardDetails 
                            request={request} 
                            parsed={parsed} 
                            cardStyle={cardStyle} 
                            annualHolidays={annualHolidays}
                            calendarExceptions={calendarExceptions}
                        />
                    </div>
                </div>
{/* 
                <ApprovalCardActions 
                    request={request}
                    onApprove={onApprove}
                    onRejectClick={onRejectClick}
                />
*/}
            </div>
        </motion.div>
    );
});

ApprovalItemCard.displayName = 'ApprovalItemCard';
export default ApprovalItemCard;
