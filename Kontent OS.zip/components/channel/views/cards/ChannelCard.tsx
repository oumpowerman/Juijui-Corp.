import React, { useState } from 'react';
import { 
  Trash2, 
  Users, 
  Layers, 
  Tag, 
  Mail, 
  BookOpen, 
  RefreshCw, 
  ExternalLink, 
  Plus, 
  ArrowLeft,
  Clock,
  Coins,
  Radio,
  Sparkles,
  Hammer
} from 'lucide-react';
import { motion } from 'framer-motion';
import { Channel, ChannelGroup } from '../../../../types';
import { PLATFORM_ICONS } from '../../../../constants';
import { PLATFORM_OPTIONS } from '../../form/inputs/PlatformGridSelector';
import { SocialLinkPreviewCard } from './SocialLinkPreviewCard';
import { formatFollowersCompact, formatThaiFollowerSyncTime } from '../../helpers/channelHelpers';
import { getRankAuraConfig } from './channelAuraConfig';
import { RankAmbientGlow, RankTopBadge } from './RankAuraDecorations';
import { BRAND_LINK_SERVICES, normalizeUrl, extractDomain } from '../../helpers/brandLinkConfig';
import { PlatformAuraButton, calculateRelativePlatformTiers } from './platform-auras';
import { useIgConnectionStatus } from '../../../../hooks/useIgConnectionStatus';

interface ChannelCardProps {
  channel: Channel;
  group?: ChannelGroup | null;
  contentCount: number;
  channelTotalFollowers: number;
  rank?: number;
  rankTitle?: string;
  onEdit: (channel: Channel) => void;
  onDelete: (id: string, name: string) => void;
  onSyncFollowers?: (channelId: string, channelName?: string) => void;
  isSyncingFollowers?: boolean;
  glow: {
    gradient: string;
    shadow: string;
    border: string;
    badgeClass: string;
    meshBg: string;
  };
  bgClass: string;
}

export const ChannelCard: React.FC<ChannelCardProps> = ({
  channel,
  group,
  contentCount,
  channelTotalFollowers,
  rank,
  rankTitle,
  onEdit,
  onDelete,
  onSyncFollowers,
  isSyncingFollowers = false,
  glow,
  bgClass,
}) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const { isChannelIgConnected } = useIgConnectionStatus();
  const isIgConnected = isChannelIgConnected(channel);
  const isPlanning = channel.status === 'PLANNING';
  const isPausedOrArchived = channel.status === 'PAUSED' || channel.status === 'ARCHIVED';
  const isInactive = isPlanning || isPausedOrArchived;
  const aura = isInactive ? null : getRankAuraConfig(rank);
  const brandLinks = channel.brand_links || [];
  const brandLinksCount = brandLinks.length;
  const channelSyncAt = channel.last_sync_followers_at || (channel.followers as any)?._last_synced_at;
  const syncTimeFormatted = channelSyncAt ? formatThaiFollowerSyncTime(channelSyncAt) : null;

  // Calculate relative platform tiers (Rank 1 by followers gets Tier 4 Apex, Rank 2 Tier 3, etc.)
  const platformTierItems = React.useMemo(() => {
    return calculateRelativePlatformTiers(channel.platforms || [], channel.followers || {});
  }, [channel.platforms, channel.followers]);

  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 25, scale: 0.96 },
        show: {
          opacity: 1,
          y: 0,
          scale: 1,
          transition: { type: 'spring', stiffness: 120, damping: 16 }
        }
      }}
      className="relative [perspective:1200px] h-full"
    >
      <motion.div
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.55, ease: [0.23, 1, 0.32, 1] }}
        style={{ transformStyle: 'preserve-3d' }}
        className="w-full h-full min-h-[440px] relative"
      >
        {/* =========================================================================
            FRONT FACE OF CARD
        ========================================================================= */}
        <div
          style={{ 
            backfaceVisibility: 'hidden', 
            WebkitBackfaceVisibility: 'hidden' 
          }}
          onClick={() => onEdit(channel)}
          className={`w-full h-full rounded-[2rem] transition-all duration-300 group flex flex-col cursor-pointer relative hover:z-30 ${
            isPlanning
              ? 'bg-gradient-to-b from-amber-50/30 via-white to-orange-50/20 border-2 border-dashed border-amber-300/85 border-b-[3.5px] border-b-amber-400/90 shadow-[0_4px_20px_rgba(245,158,11,0.06)] hover:shadow-[0_20px_45px_rgba(245,158,11,0.13)] hover:border-amber-400/95'
              : isPausedOrArchived
                ? 'bg-white grayscale-[0.65] opacity-75 hover:grayscale-0 hover:opacity-100 border border-slate-200/70 border-b-[3.5px] border-b-slate-300/80 shadow-[0_2px_10px_rgba(0,0,0,0.02)] hover:shadow-[0_16px_35px_rgba(0,0,0,0.06)]'
                : aura 
                  ? `bg-white border border-b-[3.5px] ${aura.cardBorder} ${aura.cardBevel} ${aura.cardShadow} ${aura.cardHoverShadow} ${aura.cardRing}`
                  : 'bg-white border border-b-[3.5px] border-slate-200/80 border-b-slate-200/90 shadow-[0_4px_16px_rgba(0,0,0,0.03)] hover:shadow-[0_22px_45px_rgba(0,0,0,0.07)] hover:border-b-indigo-200/90'
          }`}
        >
          {/* 3D Specular Top Rim Light */}
          <div className="pointer-events-none absolute inset-x-0 top-0 h-[1.5px] bg-gradient-to-r from-transparent via-white to-transparent opacity-90 z-20" />

          {/* Ambient Glow / Rank Aura */}
          {isPlanning ? (
            <div className="absolute -inset-[1px] rounded-[2rem] bg-gradient-to-tr from-amber-200/35 via-orange-200/25 to-amber-100/35 opacity-0 group-hover:opacity-100 blur-xl transition-all duration-500 -z-10 pointer-events-none" />
          ) : !isInactive && (
            aura ? (
              <RankAmbientGlow aura={aura} />
            ) : (
              <div className={`absolute -inset-[1px] rounded-[2rem] bg-gradient-to-tr ${glow.gradient} opacity-0 group-hover:opacity-100 blur-xl transition-all duration-500 -z-10 pointer-events-none`} />
            )
          )}

          {/* Color Bar / Banner */}
          <div className={`h-28 w-full ${isPlanning ? 'bg-gradient-to-r from-amber-200/80 via-orange-100/80 to-amber-200/80' : bgClass} relative rounded-t-[calc(2rem-2px)] overflow-hidden transition-all duration-500 ${isPausedOrArchived ? 'opacity-80 saturate-75' : ''} ${aura?.bannerBorder || ''}`}>
            {/* Mesh design on matching background */}
            <div 
              className="absolute inset-0 opacity-15"
              style={{ 
                backgroundImage: 'radial-gradient(circle, currentColor 1.2px, transparent 1.2px)', 
                backgroundSize: '10px 10px',
                color: 'inherit'
              }} 
            />

            {/* Pastel Construction Diagonal Stripes Animation for PLANNING */}
            {isPlanning && (
              <>
                <motion.div
                  animate={{ backgroundPosition: ['0px 0px', '56px 0px'] }}
                  transition={{ repeat: Infinity, duration: 4, ease: 'linear' }}
                  className="absolute inset-0 pointer-events-none opacity-60 mix-blend-multiply"
                  style={{
                    backgroundImage: 'repeating-linear-gradient(-45deg, rgba(245, 158, 11, 0.16) 0, rgba(245, 158, 11, 0.16) 14px, rgba(255, 255, 255, 0.7) 14px, rgba(255, 255, 255, 0.7) 28px)',
                    backgroundSize: '56px 56px',
                  }}
                />
                {/* Construction Caution Accent Ribbon at bottom of banner */}
                <div className="absolute bottom-0 inset-x-0 h-1 bg-gradient-to-r from-amber-400/80 via-orange-400/80 to-amber-400/80 opacity-70" />
              </>
            )}

            {/* Rank ambient mesh overlay */}
            {aura && (
              <div className={`absolute inset-0 ${aura.bannerMesh}`} />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-white/95 via-white/40 to-transparent"></div>
            
            {/* Badges in Banner */}
            <div className="absolute top-3 right-3 sm:right-4 flex items-center gap-1.5 z-10">
              {(channel.group_name || group?.name) && (
                <span 
                  className="px-2 py-0.5 text-[9px] font-black rounded-full bg-white/85 backdrop-blur-md text-slate-800 border border-white/80 border-b-[1.5px] border-b-slate-200/60 shadow-2xs hidden sm:flex items-center gap-1 max-w-[110px] truncate"
                  title={`สังกัดกลุ่ม: ${channel.group_name || group?.name}`}
                >
                  <Tag className="w-2.5 h-2.5 text-indigo-600 shrink-0" />
                  <span className="truncate">{channel.group_name || group?.name}</span>
                </span>
              )}

              {/* Operational Status Pill */}
              {isPlanning && (
                <span 
                  className="px-2.5 py-0.5 text-[9px] font-black rounded-full bg-gradient-to-r from-amber-100/95 via-orange-50/95 to-amber-100/95 text-amber-900 border border-amber-300/90 shadow-2xs flex items-center gap-1.5 shrink-0"
                  title="สถานะช่อง: อยู่ระหว่างวางแผนเตรียมงาน ก่อสร้างช่องรายการใหม่"
                >
                  <motion.span
                    animate={{ rotate: [-10, 10, -10] }}
                    transition={{ repeat: Infinity, duration: 1.4, ease: "easeInOut" }}
                    className="inline-block text-amber-600 origin-bottom"
                  >
                    <Hammer className="w-2.5 h-2.5" />
                  </motion.span>
                  <span>กำลังเตรียมงาน</span>
                  <motion.span
                    animate={{ opacity: [0.4, 1, 0.4], scale: [0.85, 1.15, 0.85] }}
                    transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
                    className="inline-block text-amber-500"
                  >
                    <Sparkles className="w-2.5 h-2.5" />
                  </motion.span>
                </span>
              )}
              {channel.status === 'PAUSED' && (
                <span 
                  className="px-2 py-0.5 text-[9px] font-black rounded-full bg-orange-100/95 text-orange-800 border border-orange-300 shadow-2xs flex items-center gap-1 shrink-0"
                  title="สถานะช่อง: พักชั่วคราว / จบซีซัน"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                  <span>พักชั่วคราว</span>
                </span>
              )}
              {channel.status === 'ARCHIVED' && (
                <span 
                  className="px-2 py-0.5 text-[9px] font-black rounded-full bg-slate-200/95 text-slate-700 border border-slate-300 shadow-2xs flex items-center gap-1 shrink-0"
                  title="สถานะช่อง: ยุติการออกอากาศ (เก็บประวัติ)"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                  <span>ปิดตัวแล้ว</span>
                </span>
              )}

              {channel.code ? (
                <span 
                  className="font-mono text-[9px] font-black uppercase tracking-wider text-indigo-700 bg-indigo-50/90 backdrop-blur-md px-2 py-0.5 rounded-full border border-indigo-200/80 shadow-2xs shrink-0 flex items-center gap-0.5"
                  title={`รหัสย่อช่อง: ${channel.code}`}
                >
                  <span className="text-indigo-400 font-bold">#</span>
                  <span>{channel.code}</span>
                </span>
              ) : (
                <span className="font-mono text-[9px] font-black uppercase tracking-widest text-slate-800/70 bg-white/40 backdrop-blur-md px-2 py-0.5 rounded-full border border-white/60 shadow-2xs shrink-0">
                  SHOW-{channel.id.substring(0, 4).toUpperCase()}
                </span>
              )}

              {/* Minimal 3D Flip Trigger */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsFlipped(true);
                }}
                className="w-6 h-6 ml-0.5 rounded-full bg-white/85 backdrop-blur-md text-slate-500 border border-white/90 border-b-[2px] border-b-slate-200/80 shadow-2xs hover:bg-white hover:text-indigo-600 hover:border-indigo-200 transition-all flex items-center justify-center active:scale-95 cursor-pointer z-20 group/flip"
                title="พลิกดูคู่มือและเอกสาร (Flip to Docs)"
              >
                <BookOpen className="w-3 h-3 group-hover/flip:scale-110 transition-transform duration-300" />
              </button>
            </div>
          </div>
          
          {/* 3D Logo Floating Crest */}
          <div className="absolute top-14 left-6 z-20">
            {aura && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-30 pointer-events-none">
                <RankTopBadge aura={aura} customTitle={rankTitle} />
              </div>
            )}

            {isPlanning && (
              <div className="absolute -top-2.5 -right-2.5 z-30 pointer-events-none">
                <span className="px-1.5 py-0.5 text-[8px] font-black uppercase rounded-md bg-amber-400 text-amber-950 shadow-xs border border-amber-200/90 flex items-center gap-0.5 tracking-wider">
                  <span>SOON</span>
                </span>
              </div>
            )}

            <div className={`w-20 h-20 rounded-2xl border-[3.5px] border-white shadow-[0_8px_20px_rgba(0,0,0,0.08)] bg-white overflow-hidden flex items-center justify-center group-hover:scale-105 group-hover:-rotate-2 transition-all duration-300 relative ${
              isPlanning
                ? 'ring-2 ring-amber-300/80 ring-offset-2 ring-offset-amber-50/60 shadow-[0_6px_16px_rgba(245,158,11,0.18)]'
                : isPausedOrArchived
                  ? 'ring-1 ring-slate-200/60 shadow-xs'
                  : aura 
                    ? `${aura.avatarHaloRing} group-hover:shadow-[0_12px_28px_rgba(245,158,11,0.3)]` 
                    : 'ring-1 ring-slate-200/60 group-hover:shadow-[0_12px_28px_rgba(99,102,241,0.18)]'
            }`}>
              {/* Blueprint Grid Background Pattern for Planning */}
              {isPlanning && (
                <div 
                  className="absolute inset-0 opacity-20 pointer-events-none"
                  style={{
                    backgroundImage: 'linear-gradient(to right, #d97706 1px, transparent 1px), linear-gradient(to bottom, #d97706 1px, transparent 1px)',
                    backgroundSize: '8px 8px'
                  }}
                />
              )}

              {channel.logoUrl ? (
                <img src={channel.logoUrl} className="w-full h-full object-cover rounded-xl relative z-10" alt="logo" />
              ) : (
                <div className={`w-full h-full flex items-center justify-center font-black text-2xl uppercase rounded-xl relative z-10 ${channel.color.split(' ')[1]}`}>
                  {channel.name.substring(0, 2)}
                </div>
              )}
            </div>
          </div>

          <div className="px-4.5 sm:px-6 py-5 sm:py-6 pt-11 flex-1 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-2">
                <div className="min-w-0 pr-2">
                  <h3 className="font-bold text-xl text-slate-800 line-clamp-1 group-hover:text-slate-900 transition-colors" title={channel.name}>
                    {channel.name}
                  </h3>
                </div>
                <div className="flex space-x-1 opacity-100 md:opacity-0 group-hover:opacity-100 transition-all duration-200 shrink-0">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete(channel.id, channel.name);
                    }}
                    className="p-1.5 text-gray-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all active:scale-95 cursor-pointer"
                    title="ลบรายการ"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {channel.description ? (
                <p className="text-xs text-slate-400 mb-4 line-clamp-2 min-h-[36px] mt-1 font-medium leading-relaxed">
                  {channel.description}
                </p>
              ) : (
                <p className="text-xs text-slate-300 italic mb-4 line-clamp-2 min-h-[36px] mt-1 leading-relaxed">
                  ไม่มีคำอธิบายช่องเพิ่มเติม
                </p>
              )}

              {/* Metrics Highlights */}
              <div className="mb-4 flex items-center gap-2 flex-wrap">
                <div 
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-b-[2px] text-xs font-bold ${
                    aura 
                      ? aura.followerPillClass 
                      : 'bg-gradient-to-b from-white to-slate-50/90 backdrop-blur-sm border-slate-200/80 border-b-slate-300/80 text-slate-700 shadow-2xs'
                  }`}
                  title={`ยอดผู้ติดตามรวม: ${channelTotalFollowers.toLocaleString()} คน${syncTimeFormatted ? ` • ตรวจล่าสุด: ${syncTimeFormatted}` : ''}`}
                >
                  <Users className={`w-3.5 h-3.5 ${aura ? 'text-current' : 'text-indigo-500'}`} />
                  <span>{channelTotalFollowers > 0 ? `${formatFollowersCompact(channelTotalFollowers)} ผู้ติดตาม` : '0 ผู้ติดตาม'}</span>

                  {/* Per-Channel Quick Sync Button */}
                  {onSyncFollowers && (
                    <button
                      type="button"
                      disabled={isSyncingFollowers}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSyncFollowers(channel.id, channel.name);
                      }}
                      className={`ml-1 -mr-1 p-0.5 rounded-lg transition-all flex items-center justify-center cursor-pointer active:scale-90 ${
                        isSyncingFollowers
                          ? 'opacity-90 cursor-wait text-indigo-600'
                          : 'text-slate-400 hover:text-indigo-600 hover:bg-indigo-50/80'
                      }`}
                      title={isSyncingFollowers ? 'กำลังดึงยอดผู้ติดตามช่องนี้...' : `ตรวจหาและอัปเดตยอดผู้ติดตามช่องนี้ทันที (1-2 วิ)${syncTimeFormatted ? ` • ตรวจล่าสุด: ${syncTimeFormatted}` : ''}`}
                    >
                      <RefreshCw className={`w-3 h-3 ${isSyncingFollowers ? 'animate-spin text-indigo-600' : ''}`} />
                    </button>
                  )}
                </div>

                {/* Per-Channel Last Sync Badge */}
                {syncTimeFormatted && (
                  <span 
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white/90 border border-slate-200/80 border-b-[2px] text-slate-600 shadow-2xs hover:bg-slate-50 transition-colors"
                    title={`เวลาตรวจเช็คยอดผู้ติดตามช่องนี้ล่าสุด: ${syncTimeFormatted}`}
                  >
                    <Clock className="w-3 h-3 text-indigo-500 shrink-0" />
                    <span>{syncTimeFormatted}</span>
                  </span>
                )}

                <span 
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border border-b-[2px] backdrop-blur-sm transition-colors shadow-2xs ${glow.badgeClass}`}
                  title={`คอนเทนต์ทั้งหมด: ${contentCount}`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>{contentCount} คอนเทนต์</span>
                </span>

                {/* Pre-launch / Pre-production Blueprint Badge for Planning channels */}
                {isPlanning && (
                  <span 
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-50 via-orange-50/80 to-amber-50 text-amber-900 border border-amber-200/90 border-b-[2px] border-b-amber-300/90 shadow-2xs"
                    title="ช่องรายการนี้อยู่ในขั้นตอนเตรียมงาน Pre-production / วางผังรายการ"
                  >
                    <motion.span
                      animate={{ rotate: [-10, 10, -10] }}
                      transition={{ repeat: Infinity, duration: 1.6, ease: "easeInOut" }}
                    >
                      🚧
                    </motion.span>
                    <span>กำลังสร้างช่อง • Pre-production</span>
                  </span>
                )}

                {/* Monetization Badge */}
                {channel.monetization?.is_monetized && (
                  <span 
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-50 via-teal-50 to-white text-emerald-800 border border-emerald-200 border-b-[2px] border-b-emerald-300/80 shadow-2xs"
                    title={channel.monetization?.monetization_note ? `สร้างรายได้: ${channel.monetization.monetization_note}` : 'เปิดสร้างรายได้เรียบร้อยแล้ว'}
                  >
                    <Coins className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>สร้างรายได้</span>
                    <span className="flex items-center gap-1 ml-0.5">
                      {channel.monetization?.youtube && (
                        <span className="text-[8px] font-black bg-rose-600 text-white px-1 py-0.5 rounded shadow-2xs" title="YouTube YPP">YT</span>
                      )}
                      {channel.monetization?.facebook && (
                        <span className="text-[8px] font-black bg-blue-600 text-white px-1 py-0.5 rounded shadow-2xs" title="Facebook In-stream Ads">FB</span>
                      )}
                    </span>
                  </span>
                )}

                {channel.email && channel.email.trim() && (
                  <a
                    href={`mailto:${channel.email.trim()}`}
                    onClick={(e) => e.stopPropagation()}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-b from-indigo-50/80 to-white text-indigo-700 border border-indigo-200/80 border-b-[2px] border-b-indigo-300/80 text-xs font-bold shadow-2xs hover:bg-indigo-100/80 hover:text-indigo-900 transition-colors max-w-full truncate"
                    title={`อีเมลติดต่อ: ${channel.email.trim()}`}
                  >
                    <Mail className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                    <span className="truncate">{channel.email.trim()}</span>
                  </a>
                )}
              </div>
            </div>

            <div className="mt-auto pt-4 border-t border-slate-100">
              <div className="flex items-center justify-between">
                
                {/* Social Links Icons with Relative Platform Aura Tiers (Sorted by followers: High -> Low) */}
                <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                  {platformTierItems.map((item, idx) => {
                    const link = channel.social_links?.[item.platform];
                    return (
                      <PlatformAuraButton
                        key={item.platform}
                        platform={item.platform}
                        followers={item.followers}
                        tier={item.tier}
                        aura={item.aura}
                        url={link}
                        channelName={channel.name}
                        channelLogoUrl={channel.logoUrl}
                        channelColor={channel.color}
                        isDominant={item.isDominant}
                        orderIndex={idx}
                        isMetaConnected={item.platform === 'INSTAGRAM' ? isIgConnected : undefined}
                      />
                    );
                  })}
                </div>

                {/* Refined Brand Docs Button (Matching Social Icons) */}
                <div className="flex items-center pl-1.5 sm:pl-2 ml-1 border-l border-slate-200/60 shrink-0">
                  <motion.button
                    type="button"
                    whileHover={{ y: -4, scale: 1.15, rotate: -5 }}
                    transition={{ type: "spring", stiffness: 400, damping: 12 }}
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsFlipped(true);
                    }}
                    className="w-8 h-8 rounded-full flex items-center justify-center transition-all z-10 relative bg-gradient-to-b from-indigo-50 to-indigo-100/80 border border-indigo-200 border-b-[2.5px] border-b-indigo-300/90 shadow-sm cursor-pointer hover:ring-2 hover:ring-indigo-400 hover:ring-offset-1 active:translate-y-[1px] active:border-b-[1px]"
                    title="เปิดดูคู่มือ Notion, บรีฟ และโฟลเดอร์ทำงาน"
                  >
                    <BookOpen className="w-4 h-4 text-indigo-600" />
                    {brandLinksCount > 0 && (
                      <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-indigo-500 text-white text-[9px] font-black rounded-full flex items-center justify-center ring-1 ring-white shadow-sm">
                        {brandLinksCount}
                      </span>
                    )}
                  </motion.button>
                </div>
                
              </div>
            </div>
          </div>
        </div>

        {/* =========================================================================
            BACK FACE OF CARD - INTERNAL DOCS HUB
        ========================================================================= */}
        <div
          style={{ 
            backfaceVisibility: 'hidden', 
            WebkitBackfaceVisibility: 'hidden',
            transform: 'rotateY(180deg)' 
          }}
          onClick={(e) => e.stopPropagation()}
          className={`absolute inset-0 w-full h-full bg-white rounded-[2rem] flex flex-col overflow-hidden z-20 ${
            isPlanning 
              ? 'border-2 border-dashed border-amber-300/85 border-b-[3.5px] border-b-amber-400/90 shadow-[0_12px_32px_rgba(245,158,11,0.08)]' 
              : 'border border-b-[3.5px] border-slate-200/80 border-b-indigo-200/90 shadow-[0_12px_32px_rgba(0,0,0,0.06)]'
          }`}
        >
          {/* 3D Specular Top Rim Light */}
          <div className="pointer-events-none absolute inset-x-0 top-0 h-[1.5px] bg-gradient-to-r from-transparent via-white to-transparent opacity-90 z-20" />

          {/* Back Header Banner */}
          <div className={`p-4 ${bgClass} relative border-b border-slate-100/80 flex items-center justify-between shrink-0`}>
            {/* Mesh Pattern */}
            <div 
              className="absolute inset-0 opacity-15"
              style={{ 
                backgroundImage: 'radial-gradient(circle, currentColor 1.2px, transparent 1.2px)', 
                backgroundSize: '10px 10px',
                color: 'inherit'
              }} 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-white/90 via-white/40 to-transparent" />

            {/* Header Identity */}
            <div className="relative z-10 flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-xl border border-white/90 shadow-sm bg-white overflow-hidden flex items-center justify-center shrink-0">
                {channel.logoUrl ? (
                  <img src={channel.logoUrl} className="w-full h-full object-cover" alt="logo" />
                ) : (
                  <div className={`w-full h-full flex items-center justify-center font-bold text-xs uppercase ${channel.color.split(' ')[1]}`}>
                    {channel.name.substring(0, 2)}
                  </div>
                )}
              </div>
              <div className="min-w-0">
                <h4 className="text-xs font-extrabold text-slate-800 truncate" title={channel.name}>
                  {channel.name}
                </h4>
                <div className="text-[10px] font-bold text-indigo-700 flex items-center gap-1">
                  <BookOpen className="w-3 h-3 text-indigo-600" />
                  <span>Internal Docs Hub ({brandLinksCount})</span>
                </div>
              </div>
            </div>

            {/* Flip Back Button */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsFlipped(false);
              }}
              className="relative z-10 px-2.5 py-1.5 rounded-xl bg-white/95 hover:bg-white text-slate-700 hover:text-indigo-600 text-xs font-bold border border-slate-200/90 border-b-[2px] border-b-slate-300/80 shadow-2xs hover:shadow-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer whitespace-nowrap shrink-0"
              title="พลิกกลับไปหน้าหลักของการ์ด"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span className="text-[11px] text-slate-600 font-semibold">กลับ</span>
            </button>
          </div>

          {/* Back Body: Links List or Empty State */}
          <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-2.5">
            {brandLinksCount === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-4 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-500 shadow-2xs">
                  <BookOpen className="w-6 h-6" />
                </div>
                <div className="space-y-1 max-w-[240px]">
                  <h5 className="text-xs font-bold text-slate-800">ยังไม่มีเอกสารคู่มือของช่องนี้</h5>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    เพิ่ม Notion SOP, บรีฟงาน Google Docs หรือโฟลเดอร์ Drive เพื่อให้ทีมเข้าถึงได้ทันที
                  </p>
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit(channel);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs active:scale-95 transition-all cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>เพิ่มเอกสารในหน้าแก้ไข</span>
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-1 flex items-center justify-between">
                  <span>คู่มือ & ลิงก์ที่เกี่ยวข้อง</span>
                  <span>คลิกเพื่อเปิดในแท็บใหม่</span>
                </div>
                {brandLinks.map((link) => {
                  const service = BRAND_LINK_SERVICES[link.type] || BRAND_LINK_SERVICES.OTHER;
                  const ServiceIcon = service.icon;
                  const displayDomain = extractDomain(link.url);

                  return (
                    <div
                      key={link.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (link.url) {
                          window.open(normalizeUrl(link.url), '_blank', 'noopener,noreferrer');
                        }
                      }}
                      className={`group/item p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${service.cardBg} ${service.borderColor} ${service.cardHoverBorder} hover:shadow-2xs active:scale-[0.99]`}
                      title={`คลิกเปิด: ${link.title || service.label} (${link.url})`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {/* Service Icon Crest */}
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow-2xs ${service.iconContainerBg}`}>
                          <ServiceIcon className="w-4 h-4 text-white" />
                        </div>

                        {/* Link Text Information */}
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <h5 className="text-xs font-bold text-slate-800 truncate group-hover/item:text-indigo-600 transition-colors">
                              {link.title || service.label}
                            </h5>
                            <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded-md ${service.badgeBg} ${service.badgeText} shrink-0`}>
                              {service.label}
                            </span>
                          </div>
                          
                          {link.description ? (
                            <p className="text-[11px] text-slate-500 truncate mt-0.5 font-normal">
                              {link.description}
                            </p>
                          ) : displayDomain ? (
                            <p className="text-[10px] text-slate-400 font-mono truncate mt-0.5">
                              {displayDomain}
                            </p>
                          ) : null}
                        </div>
                      </div>

                      {/* Open in new tab action */}
                      <div className="p-1.5 rounded-lg text-slate-400 group-hover/item:text-indigo-600 group-hover/item:bg-white/80 transition-colors shrink-0">
                        <ExternalLink className="w-4 h-4" />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Back Footer Actions */}
          <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between shrink-0">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onEdit(channel);
              }}
              className="text-xs font-bold text-slate-600 hover:text-indigo-600 flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl hover:bg-white transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>แก้ไข / เพิ่มลิงก์</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsFlipped(false);
              }}
              className="text-xs font-bold text-slate-400 hover:text-slate-700 flex items-center gap-1 px-2.5 py-1.5 rounded-xl hover:bg-white transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>พลิกกลับ</span>
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};
export default ChannelCard;