import { supabase } from '../lib/supabase';
import { LeaveRequest, LeaveType, RequestStatus } from '../types/attendance';

export const attendanceService = {
    /**
     * Fetches combined standard leave requests and dedicated OT requests.
     */
    async fetchCombinedRequests(
        userId?: string,
        options: { all?: boolean; isAdmin?: boolean; startDate?: string; endDate?: string } = {}
    ): Promise<LeaveRequest[]> {
        let query = supabase
            .from('leave_requests')
            .select(`
                *,
                profiles:profiles!leave_requests_user_id_fkey (id, full_name, avatar_url, position)
            `)
            .order('created_at', { ascending: false });
        
        if (!options.all && userId) {
            query = query.eq('user_id', userId);
        }

        if (options.startDate) {
            query = query.gte('start_date', options.startDate);
        }
        if (options.endDate) {
            query = query.lte('start_date', options.endDate);
        }

        const { data: leaveData, error: leaveError } = await query;
        if (leaveError) throw leaveError;

        const leaves: LeaveRequest[] = (leaveData || [])
            .filter((r: any) => r.type !== 'OVERTIME')
            .map((r: any) => ({
                id: r.id,
                userId: r.user_id,
                type: r.type,
                startDate: new Date(r.start_date),
                endDate: new Date(r.end_date),
                reason: r.reason,
                attachmentUrls: r.attachment_urls || [],
                status: r.status as RequestStatus,
                approverId: r.approver_id,
                createdAt: new Date(r.created_at),
                rejectionReason: r.rejection_reason,
                isHalfDay: r.is_half_day,
                halfDaySession: r.half_day_session,
            user: r.profiles ? {
                id: r.profiles.id,
                name: r.profiles.full_name,
                avatarUrl: r.profiles.avatar_url,
                position: r.profiles.position
            } : undefined
        }));

        // Fetch dedicated OT requests
        let ots: LeaveRequest[] = [];
        if (options.all && options.isAdmin) {
            let otQuery = supabase
                .from('ot_requests')
                .select(`
                    *,
                    profiles:profiles!ot_requests_user_id_fkey (id, full_name, avatar_url, position)
                `)
                .order('created_at', { ascending: false });

            if (options.startDate) {
                otQuery = otQuery.gte('date', options.startDate);
            }
            if (options.endDate) {
                otQuery = otQuery.lte('date', options.endDate);
            }

            const { data: otData, error: otError } = await otQuery;

            if (otError) throw otError;

            if (otData) {
                ots = otData.map((r: any) => ({
                    id: r.id,
                    userId: r.user_id,
                    type: 'OVERTIME' as LeaveType,
                    startDate: new Date(r.date + 'T' + r.start_time),
                    endDate: new Date(r.date + 'T' + r.end_time),
                    reason: `[OT:${r.duration_hours}hr] ${r.reason}`,
                    attachmentUrls: r.attachment_urls || [],
                    status: r.status as RequestStatus,
                    createdAt: new Date(r.created_at),
                    rejectionReason: r.rejection_reason,
                    isFixed: r.is_fixed,
                    user: r.profiles ? {
                        id: r.profiles.id,
                        name: r.profiles.full_name,
                        avatarUrl: r.profiles.avatar_url,
                        position: r.profiles.position
                    } : undefined
                }));
            }
        } else if (userId) {
            let otQuery = supabase
                .from('ot_requests')
                .select('*')
                .eq('user_id', userId)
                .order('created_at', { ascending: false });

            if (options.startDate) {
                otQuery = otQuery.gte('date', options.startDate);
            }
            if (options.endDate) {
                otQuery = otQuery.lte('date', options.endDate);
            }

            const { data: otData, error: otError } = await otQuery;

            if (otError) throw otError;

            if (otData) {
                ots = otData.map((r: any) => ({
                    id: r.id,
                    userId: r.user_id,
                    type: 'OVERTIME' as LeaveType,
                    startDate: new Date(r.date + 'T' + r.start_time),
                    endDate: new Date(r.date + 'T' + r.end_time),
                    reason: `[OT:${r.duration_hours}hr] ${r.reason}`,
                    attachmentUrls: r.attachment_urls || [],
                    status: r.status as RequestStatus,
                    createdAt: new Date(r.created_at),
                    rejectionReason: r.rejection_reason,
                    isFixed: r.is_fixed,
                    user: undefined // Will be matched with current user at hooks layer if needed
                }));
            }
        }

        // Return combined list, sorted descending by creation date
        const combined = [...leaves, ...ots];
        combined.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
        return combined;
    },

    /**
     * Inserts a new leave request.
     */
    async insertLeaveRequest(payload: {
        user_id: string;
        type: string;
        start_date: string;
        end_date: string;
        reason: string;
        attachment_urls?: string[] | null;
        status: string;
        is_half_day?: boolean;
        half_day_session?: string | null;
    }) {
        const { data, error } = await supabase
            .from('leave_requests')
            .insert(payload)
            .select()
            .single();
        if (error) throw error;
        return data;
    },

    /**
     * Inserts a new OT request.
     */
    async insertOtRequest(payload: {
        user_id: string;
        date: string;
        start_time: string;
        end_time: string;
        duration_hours: number;
        reason: string;
        type: string;
        computed_payout: number;
        base_salary_at_time: number;
        status: string;
        attachment_urls?: string[] | null;
        is_fixed?: boolean;
    }) {
        const { data, error } = await supabase
            .from('ot_requests')
            .insert(payload)
            .select()
            .single();
        if (error) throw error;
        return data;
    },

    /**
     * Updates an OT request status (APPROVED / REJECTED) and associated variables.
     */
     async updateOtRequestStatus(
        id: string,
        status: 'APPROVED' | 'REJECTED',
        updateFields: {
            duration_hours?: number;
            computed_payout?: number;
            approved_by: string;
            approved_at: string;
            rejection_reason?: string;
            start_time?: string;
            end_time?: string;
        }
    ) {
        const { data, error } = await supabase
            .from('ot_requests')
            .update({
                status,
                ...updateFields,
                // Map camelCase if needed, but db expects snake_case:
                duration_hours: updateFields.duration_hours,
                computed_payout: updateFields.computed_payout,
                approved_by: updateFields.approved_by,
                approved_at: updateFields.approved_at,
                rejection_reason: updateFields.rejection_reason,
                start_time: updateFields.start_time,
                end_time: updateFields.end_time
            })
            .eq('id', id)
            .select()
            .single();
        if (error) throw error;
        return data;
    },

    /**
     * Updates a standard leave request status (APPROVED / REJECTED).
     */
    async updateLeaveRequestStatus(
        id: string,
        status: 'APPROVED' | 'REJECTED',
        updateFields: {
            approver_id: string;
            rejection_reason?: string;
        }
    ) {
        // Fetch the existing reason to check and clean [PROVISIONAL_CHECKOUT]
        const { data: currentReq, error: fetchError } = await supabase
            .from('leave_requests')
            .select('reason')
            .eq('id', id)
            .single();
        if (fetchError) throw fetchError;

        const updateData: any = {
            status,
            approver_id: updateFields.approver_id,
            rejection_reason: updateFields.rejection_reason
        };

        if (currentReq && currentReq.reason && currentReq.reason.includes('[PROVISIONAL_CHECKOUT]')) {
            updateData.reason = currentReq.reason.replace('[PROVISIONAL_CHECKOUT]', '').trim();
        }

        const { data, error } = await supabase
            .from('leave_requests')
            .update(updateData)
            .eq('id', id)
            .select()
            .single();
        if (error) throw error;
        return data;
    },

    /**
     * Fetches standard leave history for a specific user.
     */
    async getUserLeaveHistory(userId: string): Promise<LeaveRequest[]> {
        const { data, error } = await supabase
            .from('leave_requests')
            .select('*')
            .eq('user_id', userId)
            .order('start_date', { ascending: false });
        
        if (error) throw error;
        
        return (data || []).map((r: any) => ({
            id: r.id,
            userId: r.user_id,
            type: r.type,
            startDate: new Date(r.start_date),
            endDate: new Date(r.end_date),
            reason: r.reason,
            attachmentUrls: r.attachment_urls || [],
            status: r.status as RequestStatus,
            approverId: r.approver_id,
            createdAt: new Date(r.created_at),
            rejectionReason: r.rejection_reason,
            isHalfDay: r.is_half_day,
            halfDaySession: r.half_day_session
        }));
    },

    /**
     * Records a new field / shoot checkpoint.
     */
    async createCheckpoint(checkpoint: {
        attendance_id?: string;
        user_id: string;
        location_name: string;
        latitude?: number;
        longitude?: number;
        accuracy?: number;
        note?: string;
        photo_url?: string;
    }) {
        const payload: any = {
            attendance_id: checkpoint.attendance_id || null,
            user_id: checkpoint.user_id,
            location_name: checkpoint.location_name,
            latitude: checkpoint.latitude ?? null,
            longitude: checkpoint.longitude ?? null,
            accuracy: checkpoint.accuracy ?? null,
            note: checkpoint.note || null,
            photo_url: checkpoint.photo_url || null,
            checkpoint_time: new Date().toISOString()
        };

        const { data, error } = await supabase
            .from('attendance_checkpoints')
            .insert(payload)
            .select()
            .single();

        if (error) {
            console.error("Error creating attendance checkpoint:", error);
            throw error;
        }
        return data;
    },

    /**
     * Gets checkpoints for a specific attendance log ID.
     */
    async getCheckpointsByAttendanceId(attendanceId: string) {
        if (!attendanceId) return [];
        const { data, error } = await supabase
            .from('attendance_checkpoints')
            .select('*')
            .eq('attendance_id', attendanceId)
            .order('checkpoint_time', { ascending: true });

        if (error) {
            console.error("Error fetching checkpoints for attendance:", error);
            return [];
        }
        return (data || []).map((cp: any) => ({
            id: cp.id,
            attendanceId: cp.attendance_id,
            userId: cp.user_id,
            checkpointTime: cp.checkpoint_time,
            locationName: cp.location_name,
            latitude: cp.latitude,
            longitude: cp.longitude,
            accuracy: cp.accuracy,
            note: cp.note,
            photoUrl: cp.photo_url,
            createdAt: cp.created_at
        }));
    },

    /**
     * Gets today's checkpoints for a user.
     */
    async getTodayCheckpoints(userId: string, attendanceId?: string) {
        if (!userId) return [];
        let query = supabase
            .from('attendance_checkpoints')
            .select('*')
            .eq('user_id', userId);

        if (attendanceId) {
            query = query.eq('attendance_id', attendanceId);
        } else {
            const startOfDay = new Date();
            startOfDay.setHours(0, 0, 0, 0);
            query = query.gte('checkpoint_time', startOfDay.toISOString());
        }

        const { data, error } = await query.order('checkpoint_time', { ascending: true });
        if (error) {
            console.error("Error fetching today checkpoints:", error);
            return [];
        }
        return (data || []).map((cp: any) => ({
            id: cp.id,
            attendanceId: cp.attendance_id,
            userId: cp.user_id,
            checkpointTime: cp.checkpoint_time,
            locationName: cp.location_name,
            latitude: cp.latitude,
            longitude: cp.longitude,
            accuracy: cp.accuracy,
            note: cp.note,
            photoUrl: cp.photo_url,
            createdAt: cp.created_at
        }));
    }
};
