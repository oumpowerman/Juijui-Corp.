import { SupabaseClient } from '@supabase/supabase-js';

export interface ClaimedNotificationRecord {
  id: string;
  user_id: string;
  type: string;
  title: string;
  message?: string;
  metadata?: any;
  related_id?: string;
  created_at?: string;
  retry_count?: number;
  [key: string]: any;
}

/**
 * Atomically claims all pending or orphaned notifications for a user.
 */
export async function claimPendingNotifications(
  supabaseAdmin: SupabaseClient,
  userId: string,
  triggerRecordId: string
): Promise<{ claimedRecords: ClaimedNotificationRecord[]; isOurRecordClaimed: boolean }> {
  const { data: claimedRecords, error: claimError } = await supabaseAdmin
    .from('notifications')
    .update({ line_status: 'SENDING' })
    .eq('user_id', userId)
    .or(`line_status.is.null,line_status.eq.PENDING,id.eq.${triggerRecordId}`)
    .select('*');

  if (claimError) {
    throw new Error(`DB Claim Error: ${claimError.message}`);
  }

  const isOurRecordClaimed = (claimedRecords || []).some((r: any) => r.id === triggerRecordId);

  return {
    claimedRecords: (claimedRecords as ClaimedNotificationRecord[]) || [],
    isOurRecordClaimed,
  };
}

/**
 * Resolves target destination (LINE User ID or Group ID).
 */
export async function getTargetDestination(
  supabaseAdmin: SupabaseClient,
  record: ClaimedNotificationRecord,
  submissionAlertMode?: string
): Promise<{ targetDestination: string | null; targetName: string }> {
  let targetDestination: string | null = null;
  let targetName = '';

  if (record.type === 'DAILY_SUMMARY' || record.type === 'APPROVAL_SUMMARY' || record.type === 'MONTHLY_BONUS_SUMMARY' || record.type === 'MONTHLY_OT_SUMMARY') {
    const { data: destOpt } = await supabaseAdmin
      .from('master_options')
      .select('label')
      .eq('type', 'WORK_CONFIG')
      .eq('key', 'LINE_SUMMARY_DESTINATION')
      .maybeSingle();

    if (destOpt && destOpt.label) {
      targetDestination = destOpt.label;
      targetName = 'LINE Summary Group';
    } else {
      console.log(`${record.type} requested but LINE_SUMMARY_DESTINATION is empty or not found.`);
    }
  } else if (record.type === 'COMPANY_CHECKLIST_OVERDUE_ALERT') {
    // 1. Check dedicated company checklist alert destination
    const { data: chkDestOpt } = await supabaseAdmin
      .from('master_options')
      .select('label')
      .eq('type', 'WORK_CONFIG')
      .eq('key', 'CHECKLIST_ALERT_TARGET_DESTINATION')
      .maybeSingle();

    if (chkDestOpt && chkDestOpt.label && chkDestOpt.label.trim()) {
      targetDestination = chkDestOpt.label.trim();
      targetName = 'Checklist Alert LINE Destination';
    } else {
      // 2. Fallback to general LINE Summary group
      const { data: summaryDestOpt } = await supabaseAdmin
        .from('master_options')
        .select('label')
        .eq('type', 'WORK_CONFIG')
        .eq('key', 'LINE_SUMMARY_DESTINATION')
        .maybeSingle();

      if (summaryDestOpt && summaryDestOpt.label && summaryDestOpt.label.trim()) {
        targetDestination = summaryDestOpt.label.trim();
        targetName = 'LINE Summary Group';
      } else {
        // 3. Fallback to assigned user's private LINE
        const { data: userProfile } = await supabaseAdmin
          .from('profiles')
          .select('line_user_id, full_name')
          .eq('id', record.user_id)
          .single();

        if (userProfile && userProfile.line_user_id) {
          targetDestination = userProfile.line_user_id;
          targetName = userProfile.full_name || 'User';
        }
      }
    }
  } else if (record.type === 'CONTENT_PLANNER_ALERT' || record.type === 'DAILY_OVERDUE_CONTENT_SUMMARY') {
    // 1. Check dedicated content alert destination
    const { data: contentDestOpt } = await supabaseAdmin
      .from('master_options')
      .select('label')
      .eq('type', 'WORK_CONFIG')
      .eq('key', 'CONTENT_ALERT_TARGET_DESTINATION')
      .maybeSingle();

    if (contentDestOpt && contentDestOpt.label && contentDestOpt.label.trim()) {
      targetDestination = contentDestOpt.label.trim();
      targetName = 'Content Alert LINE Destination';
    } else {
      // 2. Fallback to general LINE Summary group
      const { data: summaryDestOpt } = await supabaseAdmin
        .from('master_options')
        .select('label')
        .eq('type', 'WORK_CONFIG')
        .eq('key', 'LINE_SUMMARY_DESTINATION')
        .maybeSingle();

      if (summaryDestOpt && summaryDestOpt.label && summaryDestOpt.label.trim()) {
        targetDestination = summaryDestOpt.label.trim();
        targetName = 'LINE Summary Group';
      } else {
        // 3. Fallback to assigned user's private LINE
        const { data: userProfile } = await supabaseAdmin
          .from('profiles')
          .select('line_user_id, full_name')
          .eq('id', record.user_id)
          .single();

        if (userProfile && userProfile.line_user_id) {
          targetDestination = userProfile.line_user_id;
          targetName = userProfile.full_name || 'User';
        }
      }
    }
  } else if (record.type === 'APPROVAL_REQ' && submissionAlertMode === 'GROUP_ONLY') {
    const { data: destOpt } = await supabaseAdmin
      .from('master_options')
      .select('label')
      .eq('type', 'WORK_CONFIG')
      .eq('key', 'LINE_SUMMARY_DESTINATION')
      .maybeSingle();

    if (destOpt && destOpt.label) {
      targetDestination = destOpt.label;
      targetName = 'LINE Summary Group';
    } else {
      console.log(`APPROVAL_REQ requested in GROUP_ONLY mode but LINE_SUMMARY_DESTINATION is empty or not found.`);
    }
  } else {
    const { data: userProfile } = await supabaseAdmin
      .from('profiles')
      .select('line_user_id, full_name')
      .eq('id', record.user_id)
      .single();

    if (userProfile && userProfile.line_user_id) {
      targetDestination = userProfile.line_user_id;
      targetName = userProfile.full_name || 'User';
    }
  }

  // Sanitize LINE Destination (extract valid 33-char LINE ID like U..., C..., R... or trim whitespace)
  if (targetDestination) {
    const rawDest = targetDestination.trim();
    const match = rawDest.match(/([UCR][a-fA-F0-9]{32})/);
    targetDestination = match ? match[1] : rawDest;
  }

  return { targetDestination, targetName };
}

/**
 * Fetches LINE submission alert mode option
 */
export async function getSubmissionAlertMode(supabaseAdmin: SupabaseClient): Promise<string> {
  const { data: opt } = await supabaseAdmin
    .from('master_options')
    .select('label')
    .eq('type', 'WORK_CONFIG')
    .eq('key', 'LINE_SUBMISSION_ALERT_MODE')
    .maybeSingle();

  return opt?.label || 'ADMIN_PRIVATE';
}

/**
 * Fetches LINE work config options: LINE_APPROVAL_MODE and LINE_HEADER_TITLE
 */
export async function getWorkConfigOptions(supabaseAdmin: SupabaseClient): Promise<{
  isInteractive: boolean;
  lineHeaderTitle: string;
}> {
  const { data: modeOpt } = await supabaseAdmin
    .from('master_options')
    .select('label, is_active')
    .eq('type', 'WORK_CONFIG')
    .eq('key', 'LINE_APPROVAL_MODE')
    .maybeSingle();

  const isInteractive = modeOpt?.is_active !== false && (!modeOpt || modeOpt.label === 'INTERACTIVE');

  const { data: headerTitleOpt } = await supabaseAdmin
    .from('master_options')
    .select('label')
    .eq('type', 'WORK_CONFIG')
    .eq('key', 'LINE_HEADER_TITLE')
    .maybeSingle();

  const lineHeaderTitle = (headerTitleOpt?.label && headerTitleOpt.label.trim())
    ? headerTitleOpt.label.trim()
    : "Juijui Alert Center";

  return { isInteractive, lineHeaderTitle };
}

/**
 * Updates status to ABANDONED when no destination is found.
 */
export async function markAsAbandoned(
  supabaseAdmin: SupabaseClient,
  claimedIds: string[],
  recordType: string
): Promise<void> {
  await supabaseAdmin.from('notifications').update({
    line_status: 'ABANDONED',
    last_error: (recordType === 'DAILY_SUMMARY' || recordType === 'APPROVAL_SUMMARY' || recordType === 'MONTHLY_BONUS_SUMMARY' || recordType === 'MONTHLY_OT_SUMMARY')
      ? 'LINE_SUMMARY_DESTINATION is empty or not found in master_options'
      : 'No LINE ID linked in profile'
  }).in('id', claimedIds);
}

/**
 * Updates status to SUCCESS for claimed notifications.
 */
export async function markAsSuccess(
  supabaseAdmin: SupabaseClient,
  claimedIds: string[]
): Promise<void> {
  await supabaseAdmin.from('notifications').update({
    line_status: 'SUCCESS',
    sent_at: new Date().toISOString(),
    last_error: null
  }).in('id', claimedIds);
}

/**
 * Updates status to FAILED for claimed or individual notification record.
 */
export async function markAsFailed(
  supabaseAdmin: SupabaseClient,
  claimedIds: string[],
  record: ClaimedNotificationRecord | null,
  err: any
): Promise<void> {
  if (claimedIds.length > 0) {
    await supabaseAdmin.from('notifications').update({
      line_status: 'FAILED',
      last_error: err.message?.substring(0, 500)
    }).in('id', claimedIds);
  } else if (record && record.id) {
    const currentRetry = record.retry_count || 0;
    await supabaseAdmin.from('notifications').update({
      line_status: 'FAILED',
      retry_count: currentRetry + 1,
      last_error: err.message?.substring(0, 500)
    }).eq('id', record.id);
  }
}
