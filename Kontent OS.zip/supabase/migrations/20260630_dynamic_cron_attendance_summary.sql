-- ==========================================
-- 📊 PLAN D: DYNAMIC DAILY ATTENDANCE SUMMARY NOTIFICATION (PG_CRON)
-- ==========================================

-- 1. Ensure pg_cron extension is enabled if possible
DO $$
BEGIN
    CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA pg_catalog;
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'pg_cron extension could not be enabled automatically. Make sure it is enabled in your Supabase project.';
END;
$$;

-- 1.5. Update helper to check if a specific date is a working day for a user (respecting custom work_days)
CREATE OR REPLACE FUNCTION public.is_working_day_db(check_date DATE, check_user_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
    is_exception RECORD;
    is_holiday BOOLEAN;
    user_start_date DATE;
    day_of_week INT;
    user_work_days INT[];
BEGIN
    -- A. Check if check_date is before user's start date
    SELECT start_date, work_days INTO user_start_date, user_work_days FROM public.profiles WHERE id = check_user_id;
    IF user_start_date IS NOT NULL AND check_date < user_start_date THEN
        RETURN FALSE;
    END IF;

    -- B. Check calendar exceptions (Highest Priority)
    SELECT * INTO is_exception FROM public.calendar_exceptions WHERE date = check_date LIMIT 1;
    IF is_exception IS NOT NULL THEN
        RETURN is_exception.type = 'WORK_DAY';
    END IF;

    -- C. Check annual holidays
    SELECT EXISTS(
        SELECT 1 FROM public.annual_holidays 
        WHERE is_active = TRUE 
          AND day = EXTRACT(DAY FROM check_date) 
          AND month = EXTRACT(MONTH FROM check_date)
    ) INTO is_holiday;
    IF is_holiday THEN
        RETURN FALSE;
    END IF;

    -- D. Check user's work_days array (aligns with judgeUtils.ts date.getDay() returns 0 for Sunday, 1 for Monday...)
    day_of_week := EXTRACT(dow FROM check_date);
    
    -- If user_work_days is null or empty, default to Monday - Friday (1, 2, 3, 4, 5)
    IF user_work_days IS NULL OR cardinality(user_work_days) = 0 THEN
        user_work_days := ARRAY[1, 2, 3, 4, 5];
    END IF;

    RETURN day_of_week = ANY(user_work_days);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Insert Default Configurations for Daily Summary
INSERT INTO public.master_options (type, key, label, color, is_active, sort_order)
VALUES 
    ('WORK_CONFIG', 'DAILY_SUMMARY_DELAY_HOURS', '1', '', true, 7)
ON CONFLICT (type, key) DO NOTHING;

INSERT INTO public.master_options (type, key, label, color, is_active, sort_order)
VALUES 
    ('WORK_CONFIG', 'DAILY_SUMMARY_TIME', '18:00', '', true, 7)
ON CONFLICT (type, key) DO NOTHING;

INSERT INTO public.master_options (type, key, label, color, is_active, sort_order)
VALUES 
    ('WORK_CONFIG', 'LINE_SUMMARY_DESTINATION', '', '', true, 8)
ON CONFLICT (type, key) DO NOTHING;

-- 3. Database Function: Compile Summary and Create Trigger Notification
CREATE OR REPLACE FUNCTION public.generate_daily_attendance_summary()
RETURNS void AS $$
DECLARE
    cur_date DATE;
    start_time_val TEXT;
    late_buffer_val TEXT;
    destination_val TEXT;
    start_time_parsed TIME;
    late_buffer_minutes INT;
    late_cutoff_time TIME;
    
    -- Multiple Shifts configuration
    shifts_enabled_val TEXT;
    shifts_list_val TEXT;
    is_shifts_enabled BOOLEAN := FALSE;
    last_shift_time TIME;
    late_minutes_val INT;
    
    -- Summary counts
    ontime_count INT := 0;
    late_count INT := 0;
    leave_count INT := 0;
    absent_count INT := 0;
    
    -- Summary list texts
    ontime_list TEXT := '';
    late_list TEXT := '';
    leave_list TEXT := '';
    absent_list TEXT := '';
    
    profile_rec RECORD;
    log_rec RECORD;
    has_log BOOLEAN;
    on_leave BOOLEAN;
    leave_type_label TEXT;
    is_half_day_val BOOLEAN := FALSE;
    half_day_session_val TEXT;
    checkin_time_local TIME;
    admin_user_id UUID;
    app_name_val TEXT;
    message_content TEXT;
BEGIN
    -- Determine current date in Thailand (Asia/Bangkok timezone) to remain server-independent
    cur_date := (timezone('Asia/Bangkok'::text, now()))::DATE;

    -- Fetch config values from master_options
    SELECT label INTO start_time_val FROM public.master_options WHERE type = 'WORK_CONFIG' AND key = 'START_TIME' LIMIT 1;
    SELECT label INTO late_buffer_val FROM public.master_options WHERE type = 'WORK_CONFIG' AND key = 'LATE_BUFFER' LIMIT 1;
    SELECT label INTO destination_val FROM public.master_options WHERE type = 'WORK_CONFIG' AND key = 'LINE_SUMMARY_DESTINATION' LIMIT 1;

    -- Fetch company / system name from master_options (or default)
    SELECT label INTO app_name_val 
    FROM public.master_options 
    WHERE key IN ('COMPANY_NAME', 'SYSTEM_NAME', 'APP_NAME') 
      AND label IS NOT NULL AND label != '' 
    ORDER BY CASE key 
        WHEN 'COMPANY_NAME' THEN 1 
        WHEN 'SYSTEM_NAME' THEN 2 
        WHEN 'APP_NAME' THEN 3 
        ELSE 4 END 
    LIMIT 1;

    IF app_name_val IS NULL OR app_name_val = '' THEN
        app_name_val := 'Juijui Planner';
    END IF;

    -- Fallbacks
    IF start_time_val IS NULL THEN start_time_val := '10:00'; END IF;
    IF late_buffer_val IS NULL THEN late_buffer_val := '15'; END IF;
    
    -- If destination is empty, do not run summary to avoid spam/errors
    IF destination_val IS NULL OR destination_val = '' THEN
        RAISE NOTICE 'LINE_SUMMARY_DESTINATION is empty. Skipping daily attendance summary.';
        RETURN;
    END IF;

    -- Parse start_time and late_buffer
    BEGIN
        start_time_parsed := start_time_val::TIME;
    EXCEPTION WHEN OTHERS THEN
        start_time_parsed := '10:00'::TIME;
    END;

    BEGIN
        late_buffer_minutes := late_buffer_val::INT;
    EXCEPTION WHEN OTHERS THEN
        late_buffer_minutes := 15;
    END;

    late_cutoff_time := start_time_parsed + (late_buffer_minutes || ' minutes')::INTERVAL;

    -- Fetch multiple shifts settings
    SELECT label INTO shifts_enabled_val FROM public.master_options WHERE type = 'WORK_CONFIG' AND key = 'MULTIPLE_SHIFTS_ENABLED' LIMIT 1;
    SELECT label INTO shifts_list_val FROM public.master_options WHERE type = 'WORK_CONFIG' AND key = 'MULTIPLE_SHIFTS_LIST' LIMIT 1;

    IF shifts_enabled_val = 'true' THEN
        is_shifts_enabled := TRUE;
    END IF;

    IF is_shifts_enabled AND shifts_list_val IS NOT NULL AND shifts_list_val != '' THEN
        BEGIN
            SELECT MAX(trimmed_time::TIME)
            INTO last_shift_time
            FROM (
                SELECT TRIM(val) as trimmed_time
                FROM regexp_split_to_table(shifts_list_val, ',') as val
            ) s
            WHERE s.trimmed_time ~ '^[0-2]?[0-9]:[0-5][0-9]$' OR s.trimmed_time ~ '^[0-2]?[0-9]:[0-5][0-9]:[0-5][0-9]$';
        EXCEPTION WHEN OTHERS THEN
            last_shift_time := NULL;
        END;
    END IF;

    IF last_shift_time IS NULL THEN
        last_shift_time := start_time_parsed;
    END IF;

    -- Fetch an active ADMIN user ID to satisfy foreign key user_id on notifications
    SELECT id INTO admin_user_id FROM public.profiles WHERE is_active = TRUE AND role = 'ADMIN' LIMIT 1;
    -- If no ADMIN, get any active user
    IF admin_user_id IS NULL THEN
        SELECT id INTO admin_user_id FROM public.profiles WHERE is_active = TRUE LIMIT 1;
    END IF;
    -- If still NULL, return
    IF admin_user_id IS NULL THEN
        RETURN;
    END IF;

    -- Loop through active users (exclude ADMIN from attendance tracking)
    FOR profile_rec IN 
        SELECT id, full_name, phone_number 
        FROM public.profiles 
        WHERE is_active = TRUE AND role != 'ADMIN'
        ORDER BY full_name ASC
    LOOP
        -- Check if today is a working day for this user
        IF public.is_working_day_db(cur_date, profile_rec.id) THEN
            -- Check leave request for today (APPROVED or pending if we want, but approved is standard)
            SELECT EXISTS (
                SELECT 1 FROM public.leave_requests 
                WHERE user_id = profile_rec.id 
                  AND status = 'APPROVED'
                  AND start_date <= cur_date 
                  AND end_date >= cur_date
                  AND type IN ('SICK', 'VACATION', 'PERSONAL', 'EMERGENCY', 'UNPAID')
            ) INTO on_leave;

            -- Get leave type label if on leave
            IF on_leave THEN
                SELECT 
                    COALESCE(mo.label, lr.type),
                    lr.is_half_day,
                    lr.half_day_session
                INTO 
                    leave_type_label,
                    is_half_day_val,
                    half_day_session_val
                FROM public.leave_requests lr
                LEFT JOIN public.master_options mo ON mo.type = 'LEAVE_TYPE' AND mo.key = lr.type
                WHERE lr.user_id = profile_rec.id 
                  AND lr.status = 'APPROVED'
                  AND lr.start_date <= cur_date 
                  AND lr.end_date >= cur_date
                  AND lr.type IN ('SICK', 'VACATION', 'PERSONAL', 'EMERGENCY', 'UNPAID')
                LIMIT 1;

                IF leave_type_label IS NULL OR leave_type_label = '' THEN
                    leave_type_label := 'ลาพักผ่อน/อื่นๆ';
                END IF;

                -- ตรวจสอบเงื่อนไขการลาครึ่งวันเพื่อใส่รายละเอียดเพิ่มเติม
                IF is_half_day_val = TRUE THEN
                    IF half_day_session_val = 'AM' THEN
                        leave_type_label := leave_type_label || ' ครึ่งวันเช้า';
                    ELSIF half_day_session_val = 'PM' THEN
                        leave_type_label := leave_type_label || ' ครึ่งวันบ่าย';
                    ELSE
                        leave_type_label := leave_type_label || ' ครึ่งวัน';
                    END IF;
                END IF;

                leave_count := leave_count + 1;
                IF leave_list = '' THEN
                    leave_list := '• ' || profile_rec.full_name || ' (' || leave_type_label || ')';
                ELSE
                    leave_list := leave_list || E'\n• ' || profile_rec.full_name || ' (' || leave_type_label || ')';
                END IF;
            ELSE
                -- Check check-in log
                SELECT * INTO log_rec 
                FROM public.attendance_logs 
                WHERE user_id = profile_rec.id 
                  AND date = cur_date 
                LIMIT 1;

                IF log_rec.id IS NOT NULL AND log_rec.check_in_time IS NOT NULL THEN
                    -- User checked in! Truncate seconds to minute precision so 08:00:00 - 08:00:59 is treated as 08:00:00 (On Time)
                    checkin_time_local := (date_trunc('minute', log_rec.check_in_time AT TIME ZONE 'Asia/Bangkok'))::TIME;
                    
                    IF is_shifts_enabled THEN
                        -- Multiple Shifts is ON: Check against last shift time without buffer
                        IF checkin_time_local <= last_shift_time THEN
                            -- On-time
                            ontime_count := ontime_count + 1;
                            IF ontime_list = '' THEN
                                ontime_list := '• ' || profile_rec.full_name || ' (' || to_char(checkin_time_local, 'HH24:MI') || ' น.)';
                            ELSE
                                ontime_list := ontime_list || E'\n• ' || profile_rec.full_name || ' (' || to_char(checkin_time_local, 'HH24:MI') || ' น.)';
                            END IF;
                        ELSE
                            -- Late
                            late_count := late_count + 1;
                            
                            -- Calculate late minutes (difference between checkin_time_local and last_shift_time)
                            late_minutes_val := EXTRACT(EPOCH FROM (checkin_time_local - last_shift_time))::INT / 60;
                            IF late_minutes_val < 1 THEN late_minutes_val := 1; END IF;
                            
                            IF late_list = '' THEN
                                late_list := '• ' || profile_rec.full_name || ' (' || to_char(checkin_time_local, 'HH24:MI') || ' น. - สาย ' || late_minutes_val || ' นาที)';
                            ELSE
                                late_list := late_list || E'\n• ' || profile_rec.full_name || ' (' || to_char(checkin_time_local, 'HH24:MI') || ' น. - สาย ' || late_minutes_val || ' นาที)';
                            END IF;
                        END IF;
                    ELSE
                        -- Multiple Shifts is OFF: Same as before (using late_cutoff_time)
                        IF checkin_time_local <= late_cutoff_time THEN
                            -- On-time
                            ontime_count := ontime_count + 1;
                            IF ontime_list = '' THEN
                                ontime_list := '• ' || profile_rec.full_name || ' (' || to_char(checkin_time_local, 'HH24:MI') || ' น.)';
                            ELSE
                                ontime_list := ontime_list || E'\n• ' || profile_rec.full_name || ' (' || to_char(checkin_time_local, 'HH24:MI') || ' น.)';
                            END IF;
                        ELSE
                            -- Late
                            late_count := late_count + 1;
                            late_minutes_val := EXTRACT(EPOCH FROM (checkin_time_local - start_time_parsed))::INT / 60;
                            IF late_minutes_val < 1 THEN late_minutes_val := 1; END IF;
                            IF late_list = '' THEN
                                late_list := '• ' || profile_rec.full_name || ' (' || to_char(checkin_time_local, 'HH24:MI') || ' น. - สาย ' || late_minutes_val || ' นาที)';
                            ELSE
                                late_list := late_list || E'\n• ' || profile_rec.full_name || ' (' || to_char(checkin_time_local, 'HH24:MI') || ' น. - สาย ' || late_minutes_val || ' นาที)';
                            END IF;
                        END IF;
                    END IF;
                ELSE
                    -- Absent
                    absent_count := absent_count + 1;
                    
                    DECLARE
                        phone_suffix TEXT := '';
                    BEGIN
                        IF profile_rec.phone_number IS NOT NULL AND profile_rec.phone_number != '' THEN
                            phone_suffix := ' (โทร. ' || profile_rec.phone_number || ') 📞';
                        ELSE
                            phone_suffix := ' (ไม่ระบุเบอร์)';
                        END IF;

                        IF absent_list = '' THEN
                            absent_list := '• ' || profile_rec.full_name || phone_suffix;
                        ELSE
                            absent_list := absent_list || E'\n• ' || profile_rec.full_name || phone_suffix;
                        END IF;
                    END;
                END IF;
            END IF;
        END IF;
    END LOOP;

    -- Format lists with defaults if empty
    IF ontime_list = '' THEN ontime_list := '  (ไม่มี)'; END IF;
    IF late_list = '' THEN late_list := '  (ไม่มี)'; END IF;
    IF leave_list = '' THEN leave_list := '  (ไม่มี)'; END IF;
    IF absent_list = '' THEN absent_list := '  (ไม่มี)'; END IF;

    -- หากไม่มีพนักงานที่ต้องเข้างานในวันนี้เลย (ผลรวมเป็น 0) ให้หยุดการทำงานทันทีเพื่อไม่ให้มีสรุปส่งเข้ากลุ่ม LINE
    IF (ontime_count + late_count + leave_count + absent_count) = 0 THEN
        RAISE NOTICE 'ไม่มีพนักงานที่ต้องเข้างานในวันนี้ ข้ามการส่งรายงานสรุป';
        RETURN;
    END IF;

    -- Construct message
    message_content := '📊 สรุปรายงานการเข้างานประจำวันที่ ' || to_char(cur_date, 'DD/MM/YYYY') || E'\n\n' ||
                       '🟢 มาปกติ (' || ontime_count::TEXT || E' คน):\n' || ontime_list || E'\n\n' ||
                       '🟡 มาสาย (' || late_count::TEXT || E' คน):\n' || late_list || E'\n\n' ||
                       '🔵 ลา (' || leave_count::TEXT || E' คน):\n' || leave_list || E'\n\n' ||
                       '🔴 ขาดงาน / ยังไม่เช็คอิน (' || absent_count::TEXT || E' คน):\n' || absent_list || E'\n\n' ||
                       'ระบบสรุปรายงานอัตโนมัติ ' || app_name_val;

    -- Insert into notifications with type = 'DAILY_SUMMARY'
    -- This will trigger the Edge Function webhook automatically
    INSERT INTO public.notifications (
        user_id,
        type,
        title,
        message,
        is_read,
        link_path,
        line_status
    ) VALUES (
        admin_user_id,
        'DAILY_SUMMARY',
        '📊 รายงานการเข้างานประจำวันที่ ' || to_char(cur_date, 'DD/MM/YYYY'),
        message_content,
        FALSE,
        'ATTENDANCE',
        NULL -- Webhook triggers when line_status IS NULL
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. Create the Trigger Function that recalculates local clock and reschedules pg_cron
CREATE OR REPLACE FUNCTION public.recalculate_and_reschedule_summary_cron()
RETURNS trigger AS $$
DECLARE
    summary_time_val TEXT;
    start_time_val TEXT;
    delay_hours_val TEXT;
    start_time_parsed TIME;
    delay_hours NUMERIC;
    local_alert_time TIME;
    utc_alert_timestamp TIMESTAMP;
    utc_hour INT;
    utc_minute INT;
    cron_expr TEXT;
BEGIN
    -- Check if we are updating START_TIME, DAILY_SUMMARY_DELAY_HOURS, or DAILY_SUMMARY_TIME under WORK_CONFIG type
    IF (NEW.type = 'WORK_CONFIG' AND (NEW.key = 'START_TIME' OR NEW.key = 'DAILY_SUMMARY_DELAY_HOURS' OR NEW.key = 'DAILY_SUMMARY_TIME')) THEN
        -- Fetch DAILY_SUMMARY_TIME from database
        SELECT label INTO summary_time_val FROM public.master_options WHERE type = 'WORK_CONFIG' AND key = 'DAILY_SUMMARY_TIME' LIMIT 1;

        IF summary_time_val IS NOT NULL AND summary_time_val != '' THEN
            BEGIN
                local_alert_time := summary_time_val::TIME;
            EXCEPTION WHEN OTHERS THEN
                local_alert_time := '18:00'::TIME;
            END;
        ELSE
            -- Fallback to START_TIME + delay calculation
            SELECT label INTO start_time_val FROM public.master_options WHERE type = 'WORK_CONFIG' AND key = 'START_TIME' LIMIT 1;
            SELECT label INTO delay_hours_val FROM public.master_options WHERE type = 'WORK_CONFIG' AND key = 'DAILY_SUMMARY_DELAY_HOURS' LIMIT 1;

            IF start_time_val IS NULL THEN start_time_val := '10:00'; END IF;
            IF delay_hours_val IS NULL THEN delay_hours_val := '1'; END IF;

            BEGIN
                start_time_parsed := start_time_val::TIME;
            EXCEPTION WHEN OTHERS THEN
                start_time_parsed := '10:00'::TIME;
            END;

            BEGIN
                delay_hours := delay_hours_val::NUMERIC;
            EXCEPTION WHEN OTHERS THEN
                delay_hours := 1;
            END;

            local_alert_time := start_time_parsed + (delay_hours || ' hours')::INTERVAL;
        END IF;

        -- Convert local alert time to UTC to set up pg_cron
        utc_alert_timestamp := (CURRENT_DATE + local_alert_time) AT TIME ZONE 'Asia/Bangkok' AT TIME ZONE 'UTC';
        utc_hour := EXTRACT(HOUR FROM utc_alert_timestamp);
        utc_minute := EXTRACT(MINUTE FROM utc_alert_timestamp);

        -- Build daily cron expression: 'minute hour * * *'
        cron_expr := utc_minute || ' ' || utc_hour || ' * * *';

        -- Update/reschedule pg_cron job using SECURITY DEFINER permissions
        BEGIN
            PERFORM cron.unschedule('daily-attendance-summary');
        EXCEPTION WHEN OTHERS THEN
            -- Ignored if cron is not active or job does not exist
        END;
        
        BEGIN
            PERFORM cron.schedule('daily-attendance-summary', cron_expr, 'SELECT public.generate_daily_attendance_summary()');
        EXCEPTION WHEN OTHERS THEN
            -- Ignored
        END;
        
        RAISE NOTICE 'Rescheduled daily-attendance-summary cron job to UTC time: %:% (%)', utc_hour, utc_minute, cron_expr;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. Attach the Trigger to master_options
DROP TRIGGER IF EXISTS trg_reschedule_summary_cron ON public.master_options;
CREATE TRIGGER trg_reschedule_summary_cron
AFTER INSERT OR UPDATE ON public.master_options
FOR EACH ROW
EXECUTE FUNCTION public.recalculate_and_reschedule_summary_cron();

-- 6. Trigger Initial Execution to establish the initial scheduling right now
DO $$
DECLARE
    summary_time_val TEXT;
    start_time_val TEXT;
    delay_hours_val TEXT;
    start_time_parsed TIME;
    delay_hours NUMERIC;
    local_alert_time TIME;
    utc_alert_timestamp TIMESTAMP;
    utc_hour INT;
    utc_minute INT;
    cron_expr TEXT;
BEGIN
    SELECT label INTO summary_time_val FROM public.master_options WHERE type = 'WORK_CONFIG' AND key = 'DAILY_SUMMARY_TIME' LIMIT 1;

    IF summary_time_val IS NOT NULL AND summary_time_val != '' THEN
        BEGIN
            local_alert_time := summary_time_val::TIME;
        EXCEPTION WHEN OTHERS THEN
            local_alert_time := '18:00'::TIME;
        END;
    ELSE
        SELECT label INTO start_time_val FROM public.master_options WHERE type = 'WORK_CONFIG' AND key = 'START_TIME' LIMIT 1;
        SELECT label INTO delay_hours_val FROM public.master_options WHERE type = 'WORK_CONFIG' AND key = 'DAILY_SUMMARY_DELAY_HOURS' LIMIT 1;

        IF start_time_val IS NULL THEN start_time_val := '10:00'; END IF;
        IF delay_hours_val IS NULL THEN delay_hours_val := '1'; END IF;

        BEGIN
            start_time_parsed := start_time_val::TIME;
        EXCEPTION WHEN OTHERS THEN
            start_time_parsed := '10:00'::TIME;
        END;

        BEGIN
            delay_hours := delay_hours_val::NUMERIC;
        EXCEPTION WHEN OTHERS THEN
            delay_hours := 1;
        END;

        local_alert_time := start_time_parsed + (delay_hours || ' hours')::INTERVAL;
    END IF;

    utc_alert_timestamp := (CURRENT_DATE + local_alert_time) AT TIME ZONE 'Asia/Bangkok' AT TIME ZONE 'UTC';
    utc_hour := EXTRACT(HOUR FROM utc_alert_timestamp);
    utc_minute := EXTRACT(MINUTE FROM utc_alert_timestamp);
    cron_expr := utc_minute || ' ' || utc_hour || ' * * *';

    BEGIN
        PERFORM cron.unschedule('daily-attendance-summary');
    EXCEPTION WHEN OTHERS THEN
        -- Ignored
    END;

    BEGIN
        PERFORM cron.schedule('daily-attendance-summary', cron_expr, 'SELECT public.generate_daily_attendance_summary()');
    EXCEPTION WHEN OTHERS THEN
        -- Ignored
    END;
END;
$$;
