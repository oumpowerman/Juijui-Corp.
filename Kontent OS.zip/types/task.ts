
import { User } from './core';

export type TaskType = 'CONTENT' | 'TASK' | 'PLAN';
export type Status = 'TODO' | 'DOING' | 'DONE' | 'BLOCKED' | 'IDEA' | 'SCRIPT' | 'SHOOTING' | 'EDIT_CLIP' | 'FEEDBACK' | 'EDIT_DRAFT_1' | 'FEEDBACK_1' | 'EDIT_DRAFT_2' | 'APPROVE' | 'WAITING' | 'REVISE' | 'FINAL' | string;
export type Priority = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';

/**
 * @description แพลตฟอร์ม Social Media ปลายทางที่จะนำคอนเทนต์/คลิปไปเผยแพร่
 * เช่น YouTube, Facebook, TikTok, Instagram
 * 
 * ⚠️ คำเตือน: อย่าสับสนระหว่าง Platform กับ Channel!
 * - Platform = โซเชียลมีเดียที่จะเอาคลิปไปลง (YouTube, TikTok, FB ฯลฯ)
 * - Channel = ช่อง/แบรนด์/รายการผู้ผลิต (เช่น ช่อง Silly Buddies, ช่อง A, ช่อง B)
 * โดย 1 Channel (ช่อง) สามารถมีบัญชีโซเชียลมีเดียได้หลาย Platform
 */
export type Platform = 'YOUTUBE' | 'FACEBOOK' | 'TIKTOK' | 'INSTAGRAM' | 'OTHER' | 'ALL';

export type ContentPillar = 'ENTERTAINMENT' | 'EDUCATION' | 'LIFESTYLE' | 'PROMO' | 'REALTIME' | 'COMEDY' | 'STREET' | 'DEEP_TALK' | 'BEHIND' | 'FAN_INTERACTION' | 'OTHER' | string;
export type ContentFormat = 'SHORT_FORM' | 'LONG_FORM' | 'PICTURE' | 'ALBUM' | 'REELS' | 'STORY' | 'POST_H' | 'OTHER' | string;
export type AssetCategory = 'SCRIPT' | 'THUMBNAIL' | 'VIDEO_DRAFT' | 'INVOICE' | 'REF' | 'LINK' | 'OTHER';
export type Difficulty = 'EASY' | 'MEDIUM' | 'HARD';
export type ReviewStatus = 'PENDING' | 'PASSED' | 'REVISE' | 'EXPIRED';
export type AssigneeType = 'TEAM' | 'INDIVIDUAL';
export type FilterType = 'STATUS' | 'FORMAT' | 'CHANNEL' | 'PILLAR' | 'CATEGORY' | 'ASSIGNEE';

export interface ChannelStrategy {
    pillars: {
        key: string;
        targetPercentage: number;
        categories: {
            key: string;
            targetPercentage: number;
        }[];
    }[];
}

/**
 * @description ช่อง / รายการ / แบรนด์ผู้ผลิตคอนเทนต์ (Content Creator / Brand / Show Entity)
 * 
 * ตัวอย่าง:
 * - "Silly Buddies Studio" (ช่องหลัก)
 * - "ช่องสาระบันเทิง A" (รายการ A)
 * - "ช่องเกม B" (รายการ B)
 * 
 * แต่ละ Channel มีบัญชี Social Media ของตัวเองได้หลาย Platform
 * เช่น ช่อง A มีทั้ง YouTube (Channel A), TikTok (Channel A), Facebook (Channel A)
 */
export interface SocialLinks {
    YOUTUBE?: string;
    FACEBOOK?: string;
    TIKTOK?: string;
    INSTAGRAM?: string;
    OTHER?: string;
    [key: string]: string | undefined;
}

export interface PlatformFollowers {
    YOUTUBE?: number;
    FACEBOOK?: number;
    TIKTOK?: number;
    INSTAGRAM?: number;
    OTHER?: number;
    _last_synced_at?: string;
    [key: string]: number | string | undefined;
}

export interface ChannelGroup {
    id: string;
    name: string;
    color?: string;
    description?: string;
    sort_order?: number;
    created_at?: string;
}

export type BrandLinkType = 'NOTION' | 'GOOGLE_DOCS' | 'GOOGLE_DRIVE' | 'FIGMA' | 'SLACK' | 'WEBSITE' | 'OTHER';

export interface BrandLink {
    id: string;
    title: string;          // เช่น "คู่มือการทำคอนเทนต์ (CI Guidelines)", "Notion Content Tracker"
    url: string;            // URL ลิงก์ปลายทาง
    type: BrandLinkType;    // ประเภทบริการเพื่อเลือกแสดงไอคอนและสีที่ถูกต้อง
    description?: string;   // คำอธิบายสั้นๆ เกี่ยวกับเอกสารนั้นๆ
}

export interface ChannelMetaApiConfig {
    /** เปิดใช้งาน Meta Token เฉพาะช่องนี้ (Override global) */
    enabled?: boolean;
    /** Meta Access Token เฉพาะของแบรนด์/ช่องนี้ */
    accessToken?: string;
    /** Instagram Business Account ID เจาะจงเฉพาะช่องนี้ (ไม่บังคับ) */
    businessAccountId?: string;
}

/** สถานะการดำเนินงานของช่อง (Operational Status) */
export type ChannelStatus = 'ACTIVE' | 'PLANNING' | 'PAUSED' | 'ARCHIVED';

/** สถานะการสร้างรายได้ของช่อง (Monetization Status) */
export interface ChannelMonetization {
    /** เปิดสร้างรายได้สำเร็จอย่างน้อย 1 แพลตฟอร์มแล้วหรือไม่ */
    is_monetized: boolean;
    /** เปิดสร้างรายได้บน YouTube แล้วหรือไม่ (YPP Partner) */
    youtube?: boolean;
    /** เปิดสร้างรายได้บน Facebook แล้วหรือไม่ (In-stream / Performance Bonus) */
    facebook?: boolean;
    /** หมายเหตุเพิ่มเติมเกี่ยวกับการสร้างรายได้ เช่น วันที่เริ่มเปิด หรือรออนุมัติ */
    monetization_note?: string;
}

export interface Channel {
    /** รหัสระบุตัวตนของช่อง/รายการ */
    id: string;
    /** ชื่อของช่อง/รายการ/แบรนด์ เช่น "Silly Buddies", "Show A" */
    name: string;
    /** รหัสย่อช่อง เช่น "DE", "JJ", "DK" (แนะนำตัวพิมพ์ใหญ่ 2-6 ตัว สำหรับค้นหาด่วนและ Deep Link) */
    code?: string;
    /** คำอธิบายคอนเซปต์ของช่อง/รายการ */
    description?: string;
    /** สถานะการดำเนินงานของช่อง */
    status?: ChannelStatus;
    /** สถานะการสร้างรายได้ของช่อง */
    monetization?: ChannelMonetization;
    /** สีประจำช่อง (Tailwind class) */
    color: string;
    /** แพลตฟอร์ม Social Media ทั้งหมดที่ช่อง/รายการนี้มีบัญชีใช้งานอยู่ */
    platforms: Platform[];
    /** URL โลโก้ของช่อง/รายการ */
    logoUrl?: string;
    /** กลยุทธ์สัดส่วนคอนเทนต์ของช่อง */
    content_strategy?: ChannelStrategy | null;
    /** ลิงก์หน้าช่องหลักของแต่ละ Platform */
    social_links?: SocialLinks;
    /** จำนวนผู้ติดตามแยกตามแต่ละ Platform */
    followers?: PlatformFollowers;
    /** รหัสกลุ่มของช่อง (Channel Group ID) */
    group_id?: string | null;
    /** ชื่อกลุ่มของช่อง (Channel Group Name) */
    group_name?: string | null;
    /** อีเมลทางการของช่อง / ติดต่องาน (Official / Business Contact Email) */
    email?: string;
    /** รายการคู่มือ & เอกสารทำงานภายในของแบรนด์ (Internal Brand Docs / Guidelines) */
    brand_links?: BrandLink[];
    /** วันเวลาล่าสุดที่มีการตรวจสอบหรืออัปเดตยอดผู้ติดตาม (Follower Verification Timestamp) */
    last_sync_followers_at?: string | null;
    /** การตั้งค่า Meta Graph API เฉพาะช่องนี้ (Per-Channel Meta Override) */
    meta_api?: ChannelMetaApiConfig;
}

export interface TaskPerformance {
    views: number;
    likes: number;
    shares: number;
    comments: number;
    revenue: number;
    reflection: string;
}

export interface TaskAsset {
    id: string;
    name: string;
    url: string;
    type: 'LINK' | 'FILE';
    category: AssetCategory;
    createdAt: Date;
    /** ระบุว่าไฟล์แนบนี้คือคลิป/ภาพไฟนอลที่อนุมัติให้ส่งออกไปลงคอลัมน์ Picture Url 1 ของ Metricool */
    isMetricoolReady?: boolean;
}

export interface ReviewSession {
    id: string;
    taskId: string;
    round: number;
    scheduledAt: Date;
    reviewerId?: string | null;
    status: ReviewStatus;
    feedback?: string;
    isCompleted: boolean;
    task?: Task;

    // --- NEW: Detailed Review Tracking (Single Source of Truth) ---
    submissionNotes?: string;
    qualityScore?: number;        // 1-5 or 1-100
    feedbackCategories?: string[]; // e.g., ["Visual", "Audio", "Content"]
    submissionAssetUrl?: string;  // Snapshot of the specific file being reviewed
    manualBonus?: number;         // Manual adjustment given during review
}

export interface TaskLogChange {
    field: string;
    label: string;
    old?: string;
    new?: string;
    category?: 'STATUS_QC' | 'PEOPLE' | 'DATES' | 'FILES_STORAGE' | 'GENERAL';
}

export interface TaskLog {
    id: string;
    taskId: string;
    userId?: string;
    action: string;
    details: string;
    reason?: string;
    createdAt: Date;
    user?: { name: string; avatarUrl: string };
    metadata?: {
        changes?: TaskLogChange[];
        category?: string;
        source?: string;
        [key: string]: any;
    };
}

export interface DeadlineRequest {
    id: string;
    taskId: string;
    requestedBy: string;
    newDeadline: Date;
    reason: string;
    status: 'PENDING' | 'APPROVED' | 'REJECTED';
    createdAt: Date;
    resolvedAt?: Date;
    resolvedBy?: string;
    user?: { name: string; avatarUrl: string };
    requestType?: 'TASK' | 'GOAL';
    goalId?: string;
    taskTitle?: string;
    goalTitle?: string;
    originalDeadline?: Date;
}

export interface Client {
    id: string;
    name: string;
    contactPerson?: string;
    email?: string;
    phone?: string;
    logoUrl?: string;
    isActive: boolean;
}

export interface SponsorshipDetail {
    taskId: string;
    clientId?: string;
    client?: Client;
    isSponsored: boolean;
    dealValue: number;
    requirements?: string;
    paymentStatus: 'UNPAID' | 'PARTIAL' | 'PAID' | string;
    isPaid: boolean;
    invoiceUrl?: string;
    createdAt?: Date;
    updatedAt?: Date;
}

export interface Task {
    id: string;
    type: TaskType;
    title: string;
    description: string;
    status: Status | string;
    priority?: Priority;
    tags: string[];
    startDate: Date;
    endDate: Date;
    createdAt?: Date;
    updatedAt?: Date;
    sponsorship?: SponsorshipDetail; // Optional sponsorship data
    
    // Content specific
    /** 
     * ID ของ "ช่อง / แบรนด์ / รายการ" ที่เป็นเจ้าของคลิปนี้ (เช่น ช่อง Silly Buddies, ช่อง A) 
     */
    channelId?: string;
    /** 
     * รายการ "แพลตฟอร์มโซเชียลมีเดีย" ที่จะนำคลิปนี้ไปเผยแพร่จริง (เช่น ['YOUTUBE', 'TIKTOK', 'FACEBOOK']) 
     */
    targetPlatforms?: Platform[];
    pillar?: ContentPillar | string;
    contentFormats?: (ContentFormat | string)[]; // New multi-format support
    category?: string;
    isUnscheduled?: boolean;
    
    // People
    assigneeIds: string[];
    ideaOwnerIds?: string[];
    editorIds?: string[];
    assigneeType?: AssigneeType;
    
    // Details
    remark?: string;
    assets?: TaskAsset[];
    reviews?: ReviewSession[];
    logs?: TaskLog[];
    deadlineRequests?: DeadlineRequest[];
    
    // Gamification & Meta
    difficulty?: Difficulty;
    estimatedHours?: number;
    performance?: TaskPerformance;
    scheduledTime?: string; // HH:mm format
    
    // New fields
    targetPosition?: string;
    caution?: string;
    importance?: string;
    publishedLinks?: Record<string, string>;
    
    // Production
    shootDate?: Date;
    shootLocation?: string;
    shootTripId?: string; // New
    shootTimeStart?: string; // New
    shootTimeEnd?: string;   // New
    shootNotes?: string;     // New
    isInShootQueue?: boolean;
    isSoftFinished?: boolean;
    localPath?: string;
    driveLabel?: string;
    storageHubId?: string;

    // Sub-tasks
    contentId?: string; 
    showOnBoard?: boolean;
    parentContentTitle?: string;
    roadmapId?: string;

    // Script Link (General Task)
    scriptId?: string;

    // SLA Penalty
    sla_revert_count?: number;
    is_penalized?: boolean;
    last_penalized_at?: Date;
    hasAnalytics?: boolean;
    analyticsStatus?: 'NONE' | 'PARTIAL' | 'COMPLETE' | string;
    subChecklistProgress?: Record<string, boolean>;
    _isPartial?: boolean;

    // Routine & Personal Plan Fields
    isRoutine?: boolean;
    isMonthlyRecurring?: boolean;
    recurrence?: 'NONE' | 'MONTHLY' | 'DAILY' | 'WEEKLY' | string;
    routineStartDay?: number; // 1-31
    routineEndDay?: number;   // 1-31
    colorTheme?: string;
}

export interface ChipConfig {
    id: string;
    label: string;
    type: FilterType;
    value: string;
    colorTheme: string;
    scope?: 'CONTENT' | 'TASK' | 'PLAN';
    mode?: 'INCLUDE' | 'EXCLUDE';
}

export interface MasterOption {
    id: string;
    type: string; 
    key: string;
    label: string;
    color: string;
    sortOrder: number;
    isActive: boolean;
    isDefault?: boolean;
    parentKey?: string;
    description?: string; // Added description field
    progressValue?: number;
}

export interface TaskComment {
    id: string;
    taskId: string;
    userId: string;
    content: string;
    createdAt: Date;
    user?: User;
}

export interface StorageConfig {
    id: string;
    label: string;
    currentLetter: string;
    description?: string;
    updatedAt: Date;
}

export const getChecklistGroupKey = (statusKey: string, masterOptions: MasterOption[]): string => {
    if (!statusKey || !masterOptions) return statusKey || '';
    const statusOption = masterOptions.find(o => o.type === 'STATUS' && o.key === statusKey);
    return statusOption?.parentKey || statusKey;
};
