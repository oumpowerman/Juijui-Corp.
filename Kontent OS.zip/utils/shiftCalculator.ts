export interface ShiftCalculationResult {
    targetShift: string;    // e.g. "09:00"
    actualTime: string;     // e.g. "09:21"
    isLate: boolean;        // true if actualTime > targetShift
    lateMinutes: number;    // e.g. 21
}

/**
 * Converts HH:mm or HH:mm:ss string to total minutes from midnight
 */
export function timeToMinutes(timeStr: string): number {
    if (!timeStr) return 0;
    const parts = timeStr.trim().split(':');
    const hours = parseInt(parts[0], 10) || 0;
    const minutes = parseInt(parts[1], 10) || 0;
    return hours * 60 + minutes;
}

/**
 * Calculates the dynamic half-day offset (hours) based on MIN_HOURS.
 * - Even: MIN_HOURS / 2
 * - Odd: Math.ceil(MIN_HOURS / 2)
 */
export function getHalfDayOffset(minHours: number): number {
    const hours = minHours || 9;
    return hours % 2 === 0 ? (hours / 2) : Math.ceil(hours / 2);
}

/**
 * Calculates the transition point (in minutes from midnight) for the earliest shift.
 * If shifts list is provided and enabled, it uses the earliest sorted shift.
 * Otherwise, it uses the default start time.
 */
export function getEarliestTransitionPointMinutes(
    defaultStartTime: string,
    shiftsList: string[] = [],
    isShiftsEnabled: boolean = false,
    minHours: number = 9
): number {
    const offset = getHalfDayOffset(minHours);
    let earliestTimeStr = defaultStartTime || '08:00';
    if (isShiftsEnabled && shiftsList.length > 0) {
        const validShifts = [...shiftsList]
            .map(s => s.trim())
            .filter(s => /^\d{1,2}:\d{2}$/.test(s))
            .sort((a, b) => timeToMinutes(a) - timeToMinutes(b));
        if (validShifts.length > 0) {
            earliestTimeStr = validShifts[0];
        }
    }
    const earliestMins = timeToMinutes(earliestTimeStr);
    return earliestMins + offset * 60;
}

/**
 * Calculates matched PM shift start and check-in details.
 */
export function calculatePMShiftDetails(
    inputTimeStr: string,
    shiftsList: string[] = ['08:00', '08:30', '09:00'],
    minHours: number = 9
): { matchedMorningShift: string; matchedPMStart: string; adjustedInputTime: string } {
    const offset = getHalfDayOffset(minHours);
    const inputMins = timeToMinutes(inputTimeStr);
    
    // Subtract offset from input time (in minutes)
    const adjustedMins = (inputMins - offset * 60 + 1440) % 1440;
    const adjHours = Math.floor(adjustedMins / 60);
    const adjMinutes = adjustedMins % 60;
    const adjustedInputTime = `${adjHours.toString().padStart(2, '0')}:${adjMinutes.toString().padStart(2, '0')}`;
    
    // Find the matched morning shift using the regular shift matching helper
    const matchedMorningResult = calculateShiftAndActualTime(adjustedInputTime, shiftsList);
    const matchedMorningShift = matchedMorningResult.targetShift;
    
    // Add offset to the matched morning shift to get PM start time
    const morningShiftMins = timeToMinutes(matchedMorningShift);
    const pmStartMins = (morningShiftMins + offset * 60) % 1440;
    const pmH = Math.floor(pmStartMins / 60);
    const pmM = pmStartMins % 60;
    const matchedPMStart = `${pmH.toString().padStart(2, '0')}:${pmM.toString().padStart(2, '0')}`;
    
    return {
        matchedMorningShift,
        matchedPMStart,
        adjustedInputTime
    };
}

/**
 * Calculates the mapped target shift and actual check-in time details.
 * 
 * Logic rules:
 * - Given available shifts e.g. ['08:00', '08:30', '09:00'] sorted ascending.
 * - If inputTime <= first shift (e.g. 07:00 or 08:00):
 *     targetShift = first shift ('08:00'), actualTime = inputTime ('07:00')
 * - If inputTime is between shifts (e.g. 08:15 or 08:31):
 *     targetShift = next shift ('08:30' for 08:15, '09:00' for 08:31)
 *     actualTime = inputTime
 * - If inputTime > last shift (e.g. 09:21):
 *     targetShift = last shift ('09:00')
 *     actualTime = inputTime ('09:21')
 *     isLate = true, lateMinutes = difference
 */
export function calculateShiftAndActualTime(
    inputTimeStr: string,
    shiftsList: string[] = ['08:00', '08:30', '09:00']
): ShiftCalculationResult {
    const rawTime = (inputTimeStr || '09:00').trim();
    // Normalize HH:mm format if HH:mm:ss passed
    const timeParts = rawTime.split(':');
    const actualTimeFormatted = timeParts.length >= 2 
        ? `${timeParts[0].padStart(2, '0')}:${timeParts[1].padStart(2, '0')}`
        : rawTime;

    // Filter and sort shifts ascending
    const validShifts = Array.from(new Set(shiftsList))
        .map(s => s.trim())
        .filter(s => /^\d{1,2}:\d{2}$/.test(s))
        .sort((a, b) => timeToMinutes(a) - timeToMinutes(b));

    if (validShifts.length === 0) {
        return {
            targetShift: actualTimeFormatted,
            actualTime: actualTimeFormatted,
            isLate: false,
            lateMinutes: 0
        };
    }

    const inputMins = timeToMinutes(actualTimeFormatted);
    const firstShiftMins = timeToMinutes(validShifts[0]);
    const lastShiftMins = timeToMinutes(validShifts[validShifts.length - 1]);

    // Case 1: Early or before/at first shift (e.g. 07:00 or 08:00)
    if (inputMins <= firstShiftMins) {
        return {
            targetShift: validShifts[0],
            actualTime: actualTimeFormatted,
            isLate: false,
            lateMinutes: 0
        };
    }

    // Case 2: After last shift (e.g. 09:21 > 09:00)
    if (inputMins > lastShiftMins) {
        const lastShift = validShifts[validShifts.length - 1];
        const lateMins = inputMins - lastShiftMins;
        return {
            targetShift: lastShift,
            actualTime: actualTimeFormatted,
            isLate: true,
            lateMinutes: lateMins
        };
    }

    // Case 3: Between shifts (e.g. 08:15 -> 08:30, 08:31 -> 09:00)
    const nextShift = validShifts.find(s => timeToMinutes(s) >= inputMins) || validShifts[validShifts.length - 1];
    return {
        targetShift: nextShift,
        actualTime: actualTimeFormatted,
        isLate: false,
        lateMinutes: 0
    };
}

/**
 * Formats note string for correction / forgot check-in requests.
 */
export function formatCorrectionNote(
    targetShift: string,
    actualTime: string,
    userReason: string,
    endTime?: string
): string {
    const cleanReason = (userReason || '').trim();
    const hasCustomActual = actualTime && actualTime !== targetShift;
    
    const targetTag = `[TARGET_SHIFT:${targetShift}]`;
    const actualTag = hasCustomActual ? `[ACTUAL_CHECK_IN:${actualTime}]` : '';
    const timeTag = endTime ? `[TIME:${actualTime}-${endTime}]` : `[TIME:${actualTime}]`;

    const tags = [targetTag, actualTag, timeTag].filter(Boolean).join(' ');
    return cleanReason ? `${tags} ${cleanReason}` : tags;
}

/**
 * Calculates the earliest possible check-out time based on actual check-in time and minimum required work hours.
 * E.g., "08:12" + 9 hours -> "17:12"
 */
export function calculateRequiredCheckOutTime(checkInTimeStr: string, minHours: number): string {
    if (!checkInTimeStr) return '17:00';
    const mins = timeToMinutes(checkInTimeStr);
    const addedMins = mins + Math.round(minHours * 60);
    const resultMins = addedMins % 1440; // 1440 minutes in a day
    const hours = Math.floor(resultMins / 60);
    const minutes = resultMins % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
}

/**
 * Checks if checkoutTime is at least minHours after checkInTime, accounting for next-day wrap around if necessary.
 */
export function isValidCheckOutTime(checkInTime: string, checkOutTime: string, minHours: number): boolean {
    if (!checkInTime || !checkOutTime) return true;
    const startMins = timeToMinutes(checkInTime);
    let endMins = timeToMinutes(checkOutTime);
    
    // If checkOutTime is less than checkInTime, it has wrapped around to the next day
    if (endMins < startMins) {
        endMins += 1440;
    }
    const diffMins = endMins - startMins;
    return diffMins >= Math.round(minHours * 60);
}

