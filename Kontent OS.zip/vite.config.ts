
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
import { BRAND_CONFIG } from './config/brand.ts';
import fs from 'fs';
import path from 'path';

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  // Load env file based on `mode` in the current working directory.
  // Fix: Cast process to any to resolve TS error about cwd missing on Process type
  const env = loadEnv(mode, (process as any).cwd(), '');
  
  // Read package.json version dynamically and combine with build date
  let appVersion = '1.0.0';
  try {
    const pkgPath = path.join((process as any).cwd(), 'package.json');
    const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8'));
    const baseVersion = pkg.version || '1.0.0';
    const buildDate = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    appVersion = `v${baseVersion}-${buildDate}`;
  } catch (err) {
    console.warn('Failed to read package.json version:', err);
    const buildDate = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    appVersion = `v1.0.0-${buildDate}`;
  }

  return {
    plugins: [
      react(),
      VitePWA({
        registerType: 'prompt',
        includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'masked-icon.svg'],
        manifest: {
          name: BRAND_CONFIG.name,
          short_name: BRAND_CONFIG.title,
          description: BRAND_CONFIG.description,
          theme_color: '#4f46e5',
          background_color: '#f8fafc',
          display: 'standalone',
          orientation: 'portrait',
          share_target: {
            action: '/share_target',
            method: 'GET',
            enctype: 'application/x-www-form-urlencoded',
            params: {
              title: 'title',
              text: 'text',
              url: 'url'
            }
          },
          icons: [
            {
              src: 'icon-192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any maskable'
            },
            {
              src: 'icon-512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any maskable'
            }
          ]
        },
        workbox: {
          navigateFallbackDenylist: [/^\/api/, /^\/auth/],
          maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
        }
      }),
      {
        name: 'html-transform',
        transformIndexHtml(html) {
          return html.replace(/<title>(.*?)<\/title>/, `<title>${BRAND_CONFIG.name}</title>`)
                     .replace(/<h1 class="loader-title">(.*?)<\/h1>/, `<h1 class="loader-title">${BRAND_CONFIG.name}</h1>`)
                     .replace(/<meta name="apple-mobile-web-app-title" content="(.*?)">/, `<meta name="apple-mobile-web-app-title" content="${BRAND_CONFIG.title}">`);
        }
      }
    ],
    define: {
      // Polyfill process.env for libraries that expect it
      'process.env': {},
      // App Version Tracking
      '__APP_VERSION__': JSON.stringify(appVersion),
      // Expose environment variables to the client
      'import.meta.env.VITE_GOOGLE_CLIENT_ID': JSON.stringify(env.VITE_GOOGLE_CLIENT_ID || env.GOOGLE_CLIENT_ID || ''),
      'import.meta.env.VITE_GOOGLE_PICKER_API_KEY': JSON.stringify(env.VITE_GOOGLE_PICKER_API_KEY || env.GOOGLE_PICKER_API_KEY || env.GEMINI_API_KEY || env.VITE_GEMINI_API_KEY || ''),
      'import.meta.env.VITE_GEMINI_API_KEY': JSON.stringify(env.VITE_GEMINI_API_KEY || env.GEMINI_API_KEY || ''),
      'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY || env.VITE_GEMINI_API_KEY || ''),
      'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY || env.VITE_GEMINI_API_KEY || '')
    },
    resolve: {
      dedupe: ['react', 'react-dom', 'react/jsx-runtime', 'react/jsx-dev-runtime'],
      alias: {
        react: path.resolve((process as any).cwd(), 'node_modules/react'),
        'react-dom': path.resolve((process as any).cwd(), 'node_modules/react-dom'),
      },
    },
    optimizeDeps: {
      include: [
        'react',
        'react-dom',
        'react/jsx-runtime',
        'react/jsx-dev-runtime',
        'recharts',
        'framer-motion',
        '@tanstack/react-query',
        'lucide-react',
      ],
    },
    server: {
      host: '0.0.0.0',
      port: 3000,
      strictPort: true,
      allowedHosts: true
    },
    build: {
      outDir: 'dist',
      sourcemap: false,
      rollupOptions: {
        output: {
          manualChunks(id) {
            if (id.includes('node_modules')) {
              return 'vendor';
            }
          }
        }
      }
    }
  };
});
